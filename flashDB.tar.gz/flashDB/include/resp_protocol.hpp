#pragma once

#include "flashdb_config.hpp"
#include <string>
#include <vector>
#include <memory>
#include <sstream>

namespace flashdb {

// RESP (Redis Serialization Protocol) types
enum class RespType {
    SIMPLE_STRING,  // +
    ERROR,          // -
    INTEGER,        // :
    BULK_STRING,    // $
    ARRAY          // *
};

// RESP command structure
struct RespCommand {
    std::string command;
    std::vector<std::string> args;
    
    RespCommand() = default;
    RespCommand(const std::string& cmd, const std::vector<std::string>& arguments)
        : command(cmd), args(arguments) {}
};

// RESP response structure
struct RespResponse {
    RespType type;
    std::string data;
    std::vector<RespResponse> array_data;
    int64_t integer_data = 0;
    
    RespResponse(RespType t) : type(t) {}
    RespResponse(RespType t, const std::string& d) : type(t), data(d) {}
    RespResponse(RespType t, int64_t i) : type(t), integer_data(i) {}
    RespResponse(RespType t, const std::vector<RespResponse>& arr) : type(t), array_data(arr) {}
};

// RESP protocol parser and serializer (Dragonfly-compatible)
class RespProtocol {
public:
    // Parse RESP command from buffer
    static std::pair<RespCommand, size_t> parse_command(const char* buffer, size_t length) {
        RespCommand command;
        size_t pos = 0;
        
        if (length == 0 || buffer[0] != '*') {
            return {command, 0}; // Invalid format
        }
        
        // Parse array length
        pos = 1; // Skip '*'
        size_t array_len = 0;
        while (pos < length && buffer[pos] != '\r') {
            if (buffer[pos] >= '0' && buffer[pos] <= '9') {
                array_len = array_len * 10 + (buffer[pos] - '0');
            }
            pos++;
        }
        
        if (pos + 1 >= length || buffer[pos] != '\r' || buffer[pos + 1] != '\n') {
            return {command, 0}; // Invalid format
        }
        pos += 2; // Skip \r\n
        
        // Parse array elements
        std::vector<std::string> elements;
        elements.reserve(array_len);
        
        for (size_t i = 0; i < array_len; ++i) {
            if (pos >= length || buffer[pos] != '$') {
                return {command, 0}; // Invalid format
            }
            
            pos++; // Skip '$'
            size_t str_len = 0;
            while (pos < length && buffer[pos] != '\r') {
                if (buffer[pos] >= '0' && buffer[pos] <= '9') {
                    str_len = str_len * 10 + (buffer[pos] - '0');
                }
                pos++;
            }
            
            if (pos + 1 >= length || buffer[pos] != '\r' || buffer[pos + 1] != '\n') {
                return {command, 0}; // Invalid format
            }
            pos += 2; // Skip \r\n
            
            if (pos + str_len + 2 > length) {
                return {command, 0}; // Incomplete data
            }
            
            std::string element(buffer + pos, str_len);
            elements.push_back(element);
            pos += str_len;
            
            if (pos + 1 >= length || buffer[pos] != '\r' || buffer[pos + 1] != '\n') {
                return {command, 0}; // Invalid format
            }
            pos += 2; // Skip \r\n
        }
        
        if (!elements.empty()) {
            command.command = elements[0];
            command.args.assign(elements.begin() + 1, elements.end());
        }
        
        return {command, pos};
    }
    
    // Serialize RESP response to string
    static std::string serialize_response(const RespResponse& response) {
        std::ostringstream oss;
        
        switch (response.type) {
            case RespType::SIMPLE_STRING:
                oss << "+" << response.data << "\r\n";
                break;
                
            case RespType::ERROR:
                oss << "-" << response.data << "\r\n";
                break;
                
            case RespType::INTEGER:
                oss << ":" << response.integer_data << "\r\n";
                break;
                
            case RespType::BULK_STRING:
                if (response.data.empty()) {
                    oss << "$-1\r\n"; // Null bulk string
                } else {
                    oss << "$" << response.data.length() << "\r\n" << response.data << "\r\n";
                }
                break;
                
            case RespType::ARRAY:
                oss << "*" << response.array_data.size() << "\r\n";
                for (const auto& element : response.array_data) {
                    oss << serialize_response(element);
                }
                break;
        }
        
        return oss.str();
    }
    
    // Create standard responses
    static RespResponse ok_response() {
        return RespResponse(RespType::SIMPLE_STRING, "OK");
    }
    
    static RespResponse error_response(const std::string& message) {
        return RespResponse(RespType::ERROR, message);
    }
    
    static RespResponse null_response() {
        return RespResponse(RespType::BULK_STRING, "");
    }
    
    static RespResponse integer_response(int64_t value) {
        return RespResponse(RespType::INTEGER, value);
    }
    
    static RespResponse bulk_string_response(const std::string& value) {
        return RespResponse(RespType::BULK_STRING, value);
    }
    
    static RespResponse array_response(const std::vector<std::string>& values) {
        std::vector<RespResponse> array_data;
        array_data.reserve(values.size());
        for (const auto& value : values) {
            array_data.emplace_back(RespType::BULK_STRING, value);
        }
        return RespResponse(RespType::ARRAY, array_data);
    }
};

// Command processor for Redis-compatible commands
class CommandProcessor {
private:
    class DashTable* table_; // Forward declaration
    
public:
    explicit CommandProcessor(DashTable* table) : table_(table) {}
    
    // Process RESP command and generate response
    RespResponse process_command(const RespCommand& command);
    
private:
    // Individual command handlers
    RespResponse handle_ping(const std::vector<std::string>& args);
    RespResponse handle_get(const std::vector<std::string>& args);
    RespResponse handle_set(const std::vector<std::string>& args);
    RespResponse handle_del(const std::vector<std::string>& args);
    RespResponse handle_exists(const std::vector<std::string>& args);
    RespResponse handle_mget(const std::vector<std::string>& args);
    RespResponse handle_mset(const std::vector<std::string>& args);
    RespResponse handle_incr(const std::vector<std::string>& args);
    RespResponse handle_decr(const std::vector<std::string>& args);
    RespResponse handle_info(const std::vector<std::string>& args);
    RespResponse handle_flushall(const std::vector<std::string>& args);
    
    // Utility functions
    bool is_integer(const std::string& str);
    int64_t string_to_integer(const std::string& str);
    std::string integer_to_string(int64_t value);
};

} // namespace flashdb