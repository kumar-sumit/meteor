#pragma once

#include "flashdb_config.hpp"
#include "resp_protocol.hpp"
#include "thread_pool.hpp"
#include <liburing.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <memory>
#include <atomic>
#include <unordered_map>
#include <queue>

namespace flashdb {

// I/O operation types for io_uring
enum class IOOpType {
    ACCEPT,
    READ,
    WRITE,
    CLOSE
};

// I/O operation context
struct IOOperation {
    IOOpType type;
    int fd;
    std::unique_ptr<Connection> connection;
    std::vector<char> buffer;
    size_t buffer_size;
    std::chrono::steady_clock::time_point start_time;
    
    IOOperation(IOOpType t, int socket_fd) 
        : type(t), fd(socket_fd), start_time(std::chrono::steady_clock::now()) {}
};

// High-performance io_uring-based network server (Dragonfly-style)
class IOUringServer {
private:
    int listen_fd_;
    struct io_uring ring_;
    std::atomic<bool> running_{false};
    RuntimeConfig config_;
    
    // Connection management
    std::unordered_map<int, std::unique_ptr<Connection>> connections_;
    std::mutex connections_mutex_;
    
    // I/O operation pool for memory efficiency
    std::queue<std::unique_ptr<IOOperation>> operation_pool_;
    std::mutex pool_mutex_;
    
    // Thread pool and shard manager
    std::unique_ptr<ShardManager> shard_manager_;
    std::unique_ptr<CommandProcessor> command_processor_;
    
    // Performance statistics
    std::atomic<uint64_t> total_connections_{0};
    std::atomic<uint64_t> total_commands_{0};
    std::atomic<uint64_t> total_bytes_read_{0};
    std::atomic<uint64_t> total_bytes_written_{0};
    std::atomic<uint64_t> io_operations_submitted_{0};
    std::atomic<uint64_t> io_operations_completed_{0};
    
    // io_uring configuration
    static constexpr unsigned RING_SIZE = 4096;
    static constexpr unsigned BATCH_SIZE = 64;
    
public:
    explicit IOUringServer(const RuntimeConfig& config)
        : config_(config) {
        
        shard_manager_ = std::make_unique<ShardManager>(config_.thread_count);
    }
    
    ~IOUringServer() {
        stop();
    }
    
    // Start server with io_uring
    bool start() {
        if (running_.load()) {
            return false;
        }
        
        // Initialize io_uring
        if (io_uring_queue_init(RING_SIZE, &ring_, 0) < 0) {
            std::cerr << "Failed to initialize io_uring" << std::endl;
            return false;
        }
        
        // Create listening socket
        listen_fd_ = socket(AF_INET, SOCK_STREAM, 0);
        if (listen_fd_ < 0) {
            io_uring_queue_exit(&ring_);
            return false;
        }
        
        // Set socket options
        int opt = 1;
        setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        
        // Make socket non-blocking
        set_non_blocking(listen_fd_);
        
        // Bind socket
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(config_.port);
        addr.sin_addr.s_addr = INADDR_ANY;
        
        if (bind(listen_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
            close(listen_fd_);
            io_uring_queue_exit(&ring_);
            return false;
        }
        
        // Listen for connections
        if (listen(listen_fd_, SOMAXCONN) < 0) {
            close(listen_fd_);
            io_uring_queue_exit(&ring_);
            return false;
        }
        
        // Submit initial accept operation
        submit_accept();
        
        running_.store(true);
        return true;
    }
    
    // Stop server
    void stop() {
        if (!running_.load()) {
            return;
        }
        
        running_.store(false);
        
        // Close all connections
        {
            std::lock_guard<std::mutex> lock(connections_mutex_);
            for (auto& [fd, conn] : connections_) {
                close(fd);
            }
            connections_.clear();
        }
        
        // Close server socket and cleanup io_uring
        if (listen_fd_ >= 0) {
            close(listen_fd_);
        }
        
        io_uring_queue_exit(&ring_);
        
        // Shutdown shard manager
        if (shard_manager_) {
            shard_manager_->shutdown();
        }
    }
    
    // Main io_uring event loop (Dragonfly-inspired)
    void run() {
        if (!running_.load()) {
            return;
        }
        
        std::cout << "Starting io_uring event loop..." << std::endl;
        
        while (running_.load()) {
            // Submit pending operations in batches
            submit_batch_operations();
            
            // Wait for completions
            struct io_uring_cqe* cqe;
            int ret = io_uring_wait_cqe(&ring_, &cqe);
            
            if (ret < 0) {
                if (errno == EINTR) {
                    continue;
                }
                std::cerr << "io_uring_wait_cqe error: " << strerror(-ret) << std::endl;
                break;
            }
            
            // Process completions in batch
            unsigned completed = 0;
            struct io_uring_cqe* cqes[BATCH_SIZE];
            
            // Peek multiple completions
            cqes[completed++] = cqe;
            while (completed < BATCH_SIZE) {
                ret = io_uring_peek_cqe(&ring_, &cqes[completed]);
                if (ret < 0) break;
                completed++;
            }
            
            // Process all completed operations
            for (unsigned i = 0; i < completed; ++i) {
                process_completion(cqes[i]);
                io_uring_cqe_seen(&ring_, cqes[i]);
            }
            
            io_operations_completed_.fetch_add(completed);
        }
    }
    
    // Get server statistics
    struct Statistics {
        uint64_t total_connections;
        uint64_t active_connections;
        uint64_t total_commands;
        uint64_t total_bytes_read;
        uint64_t total_bytes_written;
        uint64_t io_operations_submitted;
        uint64_t io_operations_completed;
        size_t total_keys;
        size_t shard_count;
        double io_efficiency; // completed/submitted ratio
    };
    
    Statistics get_statistics() const {
        Statistics stats;
        stats.total_connections = total_connections_.load();
        stats.total_commands = total_commands_.load();
        stats.total_bytes_read = total_bytes_read_.load();
        stats.total_bytes_written = total_bytes_written_.load();
        stats.io_operations_submitted = io_operations_submitted_.load();
        stats.io_operations_completed = io_operations_completed_.load();
        stats.total_keys = shard_manager_ ? shard_manager_->total_size() : 0;
        stats.shard_count = shard_manager_ ? shard_manager_->shard_count() : 0;
        
        if (stats.io_operations_submitted > 0) {
            stats.io_efficiency = static_cast<double>(stats.io_operations_completed) / stats.io_operations_submitted;
        } else {
            stats.io_efficiency = 0.0;
        }
        
        {
            std::lock_guard<std::mutex> lock(connections_mutex_);
            stats.active_connections = connections_.size();
        }
        
        return stats;
    }
    
private:
    void set_non_blocking(int fd) {
        int flags = fcntl(fd, F_GETFL, 0);
        fcntl(fd, F_SETFL, flags | O_NONBLOCK);
    }
    
    // Get or create I/O operation from pool
    std::unique_ptr<IOOperation> get_operation(IOOpType type, int fd) {
        std::unique_ptr<IOOperation> op;
        
        {
            std::lock_guard<std::mutex> lock(pool_mutex_);
            if (!operation_pool_.empty()) {
                op = std::move(operation_pool_.front());
                operation_pool_.pop();
                
                // Reset operation
                op->type = type;
                op->fd = fd;
                op->connection = nullptr;
                op->buffer.clear();
                op->start_time = std::chrono::steady_clock::now();
            }
        }
        
        if (!op) {
            op = std::make_unique<IOOperation>(type, fd);
        }
        
        return op;
    }
    
    // Return operation to pool
    void return_operation(std::unique_ptr<IOOperation> op) {
        std::lock_guard<std::mutex> lock(pool_mutex_);
        operation_pool_.push(std::move(op));
    }
    
    // Submit accept operation
    void submit_accept() {
        auto op = get_operation(IOOpType::ACCEPT, listen_fd_);
        
        struct io_uring_sqe* sqe = io_uring_get_sqe(&ring_);
        if (!sqe) {
            return_operation(std::move(op));
            return;
        }
        
        io_uring_prep_accept(sqe, listen_fd_, nullptr, nullptr, 0);
        io_uring_sqe_set_data(sqe, op.release());
        
        io_operations_submitted_.fetch_add(1);
    }
    
    // Submit read operation
    void submit_read(int client_fd, std::unique_ptr<Connection> connection) {
        auto op = get_operation(IOOpType::READ, client_fd);
        op->connection = std::move(connection);
        op->buffer.resize(Config::NETWORK_BUFFER_SIZE);
        
        struct io_uring_sqe* sqe = io_uring_get_sqe(&ring_);
        if (!sqe) {
            return_operation(std::move(op));
            return;
        }
        
        io_uring_prep_read(sqe, client_fd, op->buffer.data(), op->buffer.size(), 0);
        io_uring_sqe_set_data(sqe, op.release());
        
        io_operations_submitted_.fetch_add(1);
    }
    
    // Submit write operation
    void submit_write(int client_fd, std::unique_ptr<Connection> connection, const std::string& data) {
        auto op = get_operation(IOOpType::WRITE, client_fd);
        op->connection = std::move(connection);
        op->buffer.assign(data.begin(), data.end());
        
        struct io_uring_sqe* sqe = io_uring_get_sqe(&ring_);
        if (!sqe) {
            return_operation(std::move(op));
            return;
        }
        
        io_uring_prep_write(sqe, client_fd, op->buffer.data(), op->buffer.size(), 0);
        io_uring_sqe_set_data(sqe, op.release());
        
        io_operations_submitted_.fetch_add(1);
    }
    
    // Submit operations in batch (Dragonfly-style batching)
    void submit_batch_operations() {
        int submitted = io_uring_submit(&ring_);
        if (submitted > 0) {
            // Batching successful
        }
    }
    
    // Process completed I/O operation
    void process_completion(struct io_uring_cqe* cqe) {
        auto* op = static_cast<IOOperation*>(io_uring_cqe_get_data(cqe));
        if (!op) {
            return;
        }
        
        std::unique_ptr<IOOperation> operation(op);
        int result = cqe->res;
        
        switch (operation->type) {
            case IOOpType::ACCEPT:
                handle_accept_completion(result);
                break;
                
            case IOOpType::READ:
                handle_read_completion(std::move(operation), result);
                break;
                
            case IOOpType::WRITE:
                handle_write_completion(std::move(operation), result);
                break;
                
            case IOOpType::CLOSE:
                handle_close_completion(std::move(operation), result);
                break;
        }
    }
    
    void handle_accept_completion(int result) {
        if (result < 0) {
            std::cerr << "Accept error: " << strerror(-result) << std::endl;
            // Re-submit accept for next connection
            submit_accept();
            return;
        }
        
        int client_fd = result;
        set_non_blocking(client_fd);
        
        // Create connection
        auto connection = std::make_unique<Connection>(client_fd);
        
        {
            std::lock_guard<std::mutex> lock(connections_mutex_);
            connections_[client_fd] = std::make_unique<Connection>(client_fd);
        }
        
        total_connections_.fetch_add(1);
        
        // Submit read operation for new connection
        submit_read(client_fd, std::move(connection));
        
        // Re-submit accept for next connection
        submit_accept();
    }
    
    void handle_read_completion(std::unique_ptr<IOOperation> op, int result) {
        if (result <= 0) {
            // Connection closed or error
            close_connection(op->fd);
            return_operation(std::move(op));
            return;
        }
        
        // Process received data
        std::string data(op->buffer.data(), result);
        op->connection->read_buffer += data;
        op->connection->bytes_read += result;
        total_bytes_read_.fetch_add(result);
        
        // Process complete commands
        process_commands(*op->connection);
        
        // Submit next read operation
        submit_read(op->fd, std::move(op->connection));
        return_operation(std::move(op));
    }
    
    void handle_write_completion(std::unique_ptr<IOOperation> op, int result) {
        if (result <= 0) {
            // Write error
            close_connection(op->fd);
            return_operation(std::move(op));
            return;
        }
        
        total_bytes_written_.fetch_add(result);
        
        // Submit next read operation
        submit_read(op->fd, std::move(op->connection));
        return_operation(std::move(op));
    }
    
    void handle_close_completion(std::unique_ptr<IOOperation> op, int result) {
        // Connection cleanup completed
        return_operation(std::move(op));
    }
    
    void process_commands(Connection& conn) {
        size_t pos = 0;
        
        while (pos < conn.read_buffer.size()) {
            auto [command, consumed] = RespProtocol::parse_command(
                conn.read_buffer.data() + pos, 
                conn.read_buffer.size() - pos
            );
            
            if (consumed == 0) {
                break; // Incomplete command
            }
            
            // Process command
            total_commands_.fetch_add(1);
            
            if (command_processor_) {
                RespResponse response = command_processor_->process_command(command);
                std::string response_str = RespProtocol::serialize_response(response);
                
                // Submit write operation for response
                auto connection_copy = std::make_unique<Connection>(conn.fd);
                connection_copy->read_buffer = conn.read_buffer;
                connection_copy->bytes_read = conn.bytes_read;
                
                submit_write(conn.fd, std::move(connection_copy), response_str);
            }
            
            pos += consumed;
        }
        
        // Remove processed data
        if (pos > 0) {
            conn.read_buffer.erase(0, pos);
        }
    }
    
    void close_connection(int fd) {
        close(fd);
        
        {
            std::lock_guard<std::mutex> lock(connections_mutex_);
            connections_.erase(fd);
        }
    }
};

} // namespace flashdb