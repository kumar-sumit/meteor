#pragma once

#include "flashdb_config.hpp"
#include <thread>
#include <vector>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <functional>
#include <atomic>
#include <memory>

namespace flashdb {

// Task type for thread pool
using Task = std::function<void()>;

// High-performance thread pool (Dragonfly-inspired shared-nothing design)
class ThreadPool {
private:
    std::vector<std::thread> workers_;
    std::vector<std::queue<Task>> task_queues_;
    std::vector<std::mutex> queue_mutexes_;
    std::vector<std::condition_variable> queue_conditions_;
    std::atomic<bool> stop_{false};
    std::atomic<size_t> next_queue_{0};
    size_t thread_count_;
    
public:
    explicit ThreadPool(size_t thread_count = Config::DEFAULT_THREADS)
        : thread_count_(thread_count) {
        
        task_queues_.resize(thread_count_);
        queue_mutexes_.resize(thread_count_);
        queue_conditions_.resize(thread_count_);
        workers_.reserve(thread_count_);
        
        // Create worker threads
        for (size_t i = 0; i < thread_count_; ++i) {
            workers_.emplace_back([this, i] { worker_loop(i); });
        }
    }
    
    ~ThreadPool() {
        stop();
        join();
    }
    
    // Submit task to thread pool
    template<typename F>
    void submit(F&& task) {
        if (stop_.load()) {
            return;
        }
        
        // Round-robin task distribution
        size_t queue_idx = next_queue_.fetch_add(1) % thread_count_;
        
        {
            std::lock_guard<std::mutex> lock(queue_mutexes_[queue_idx]);
            task_queues_[queue_idx].emplace(std::forward<F>(task));
        }
        
        queue_conditions_[queue_idx].notify_one();
    }
    
    // Submit task to specific thread (for CPU affinity)
    template<typename F>
    void submit_to_thread(size_t thread_id, F&& task) {
        if (stop_.load() || thread_id >= thread_count_) {
            return;
        }
        
        {
            std::lock_guard<std::mutex> lock(queue_mutexes_[thread_id]);
            task_queues_[thread_id].emplace(std::forward<F>(task));
        }
        
        queue_conditions_[thread_id].notify_one();
    }
    
    // Get thread count
    size_t size() const {
        return thread_count_;
    }
    
    // Stop thread pool
    void stop() {
        stop_.store(true);
        for (auto& cv : queue_conditions_) {
            cv.notify_all();
        }
    }
    
    // Join all threads
    void join() {
        for (auto& worker : workers_) {
            if (worker.joinable()) {
                worker.join();
            }
        }
    }
    
private:
    void worker_loop(size_t thread_id) {
        // Set thread affinity (simplified)
        set_thread_affinity(thread_id);
        
        while (!stop_.load()) {
            Task task;
            
            {
                std::unique_lock<std::mutex> lock(queue_mutexes_[thread_id]);
                queue_conditions_[thread_id].wait(lock, [this, thread_id] {
                    return stop_.load() || !task_queues_[thread_id].empty();
                });
                
                if (stop_.load()) {
                    break;
                }
                
                if (!task_queues_[thread_id].empty()) {
                    task = std::move(task_queues_[thread_id].front());
                    task_queues_[thread_id].pop();
                }
            }
            
            if (task) {
                try {
                    task();
                } catch (...) {
                    // Log error (simplified)
                }
            }
        }
    }
    
    void set_thread_affinity(size_t thread_id) {
        // Platform-specific thread affinity setting
        // This is simplified - real implementation would use pthread_setaffinity_np on Linux
        // or SetThreadAffinityMask on Windows
        (void)thread_id; // Suppress unused parameter warning
    }
};

// Per-thread shard manager (Dragonfly's shared-nothing approach)
class ShardManager {
private:
    std::vector<std::unique_ptr<class DashTable>> shards_;
    std::unique_ptr<ThreadPool> thread_pool_;
    size_t shard_count_;
    
public:
    explicit ShardManager(size_t shard_count = Config::DEFAULT_THREADS)
        : shard_count_(shard_count) {
        
        thread_pool_ = std::make_unique<ThreadPool>(shard_count_);
        shards_.reserve(shard_count_);
        
        // Create one shard per thread
        for (size_t i = 0; i < shard_count_; ++i) {
            shards_.emplace_back(std::make_unique<class DashTable>());
        }
    }
    
    // Get shard for key
    size_t get_shard_id(const std::string& key) const {
        // Simple hash-based sharding
        uint64_t hash = 0;
        for (char c : key) {
            hash = hash * 31 + static_cast<uint64_t>(c);
        }
        return hash % shard_count_;
    }
    
    // Execute operation on appropriate shard
    template<typename F>
    auto execute_on_shard(const std::string& key, F&& operation) -> decltype(operation(std::declval<DashTable&>())) {
        size_t shard_id = get_shard_id(key);
        return operation(*shards_[shard_id]);
    }
    
    // Execute operation asynchronously
    template<typename F>
    void execute_async(const std::string& key, F&& operation) {
        size_t shard_id = get_shard_id(key);
        thread_pool_->submit_to_thread(shard_id, [this, shard_id, operation = std::forward<F>(operation)]() {
            operation(*shards_[shard_id]);
        });
    }
    
    // Get statistics
    size_t total_size() const {
        size_t total = 0;
        for (const auto& shard : shards_) {
            total += shard->size();
        }
        return total;
    }
    
    size_t shard_count() const {
        return shard_count_;
    }
    
    ThreadPool& thread_pool() {
        return *thread_pool_;
    }
    
    // Shutdown
    void shutdown() {
        if (thread_pool_) {
            thread_pool_->stop();
            thread_pool_->join();
        }
    }
};

} // namespace flashdb