#pragma once

#include <cstdint>
#include <string>
#include <cstddef>

namespace flashdb {

// Configuration constants based on Dragonfly's architecture
struct Config {
    // Dashtable configuration
    static constexpr size_t SEGMENT_SIZE = 56;           // Regular buckets per segment
    static constexpr size_t STASH_SIZE = 4;              // Stash buckets per segment  
    static constexpr size_t BUCKET_SIZE = 14;            // Slots per bucket
    static constexpr size_t INITIAL_SEGMENTS = 1024;     // Initial number of segments
    
    // Cache policy configuration (2Q/LFRU)
    static constexpr float PROBATIONARY_RATIO = 0.067f;  // ~6.7% probationary space
    static constexpr size_t MAX_PROBATIONARY_SHIFTS = 14; // Max shifts before eviction
    
    // Thread and networking configuration
    static constexpr size_t DEFAULT_THREADS = 8;         // Default worker threads
    static constexpr uint16_t DEFAULT_PORT = 6380;       // Default server port
    static constexpr size_t MAX_CONNECTIONS = 10000;     // Max concurrent connections
    
    // Memory and performance settings
    static constexpr size_t DEFAULT_MEMORY_LIMIT = 2ULL * 1024 * 1024 * 1024; // 2GB
    static constexpr size_t CACHE_LINE_SIZE = 64;        // CPU cache line size
    static constexpr size_t MAX_VALUE_SIZE = 512 * 1024 * 1024; // 512MB max value
    
    // I/O and batching configuration
    static constexpr size_t IO_BATCH_SIZE = 32;          // I/O operations per batch
    static constexpr size_t NETWORK_BUFFER_SIZE = 16384; // Network buffer size
    static constexpr size_t PIPELINE_DEPTH = 128;        // Command pipeline depth
    
    // Benchmark and testing
    static constexpr size_t BENCHMARK_KEYS = 1000000;    // Default benchmark key count
    static constexpr size_t BENCHMARK_THREADS = 16;      // Default benchmark threads
};

// Runtime configuration
struct RuntimeConfig {
    std::string bind_address = "127.0.0.1";
    uint16_t port = Config::DEFAULT_PORT;
    size_t thread_count = Config::DEFAULT_THREADS;
    size_t memory_limit = Config::DEFAULT_MEMORY_LIMIT;
    bool enable_clustering = false;
    bool enable_persistence = false;
    std::string log_level = "info";
    std::string data_dir = "./data";
};

} // namespace flashdb