#pragma once

#include "flashdb_config.hpp"
#include <atomic>
#include <memory>
#include <vector>
#include <string>
#include <functional>
#include <cstring>
#include <mutex>
#include <shared_mutex>
#include <array>
#include <iostream>

namespace flashdb {

// Forward declarations
class DashEntry;
class DashBucket;
class DashSegment;

// Hash function for keys (based on Dragonfly's approach)
class DashHash {
public:
    static uint64_t hash(const std::string& key) {
        return hash(key.data(), key.size());
    }
    
    static uint64_t hash(const char* data, size_t len) {
        // Simple FNV-1a hash (can be optimized with xxHash later)
        uint64_t hash = 14695981039346656037ULL;
        for (size_t i = 0; i < len; ++i) {
            hash ^= static_cast<uint64_t>(data[i]);
            hash *= 1099511628211ULL;
        }
        return hash;
    }
    
    static uint32_t segment_id(uint64_t hash, size_t segment_count) {
        return static_cast<uint32_t>(hash % segment_count);
    }
    
    static std::pair<uint32_t, uint32_t> bucket_ids(uint64_t hash) {
        // Two bucket candidates within a segment (Dragonfly approach)
        uint32_t bucket1 = static_cast<uint32_t>(hash % Config::SEGMENT_SIZE);
        uint32_t bucket2 = static_cast<uint32_t>((hash >> 16) % Config::SEGMENT_SIZE);
        if (bucket1 == bucket2) {
            bucket2 = (bucket1 + 1) % Config::SEGMENT_SIZE;
        }
        return {bucket1, bucket2};
    }
};

// Cache entry with rank-based positioning (Dragonfly's 2Q implementation)
class DashEntry {
public:
    std::string key;
    std::string value;
    uint64_t hash_value;
    std::atomic<uint64_t> access_count{0};
    std::atomic<bool> is_probationary{true};
    
    DashEntry() = default;
    DashEntry(const std::string& k, const std::string& v, uint64_t h)
        : key(k), value(v), hash_value(h) {}
    
    // Move constructor for efficiency
    DashEntry(DashEntry&& other) noexcept
        : key(std::move(other.key))
        , value(std::move(other.value))
        , hash_value(other.hash_value)
        , access_count(other.access_count.load())
        , is_probationary(other.is_probationary.load()) {}
    
    DashEntry& operator=(DashEntry&& other) noexcept {
        if (this != &other) {
            key = std::move(other.key);
            value = std::move(other.value);
            hash_value = other.hash_value;
            access_count.store(other.access_count.load());
            is_probationary.store(other.is_probationary.load());
        }
        return *this;
    }
    
    void record_access() {
        access_count.fetch_add(1, std::memory_order_relaxed);
    }
    
    bool should_promote() const {
        return is_probationary.load() && access_count.load() > 0;
    }
};

// Bucket with ranked slots (Dragonfly's design)
class DashBucket {
private:
    std::array<std::unique_ptr<DashEntry>, Config::BUCKET_SIZE> slots_;
    std::atomic<size_t> size_{0};
    mutable std::mutex mutex_; // Fine-grained locking per bucket
    
public:
    DashBucket() {
        for (auto& slot : slots_) {
            slot = nullptr;
        }
    }
    
    // Find entry by key
    DashEntry* find(const std::string& key) {
        std::lock_guard<std::mutex> lock(mutex_);
        for (auto& slot : slots_) {
            if (slot && slot->key == key) {
                slot->record_access();
                return slot.get();
            }
        }
        return nullptr;
    }
    
    // Insert entry (with rank-based positioning)
    bool insert(std::unique_ptr<DashEntry> entry) {
        std::lock_guard<std::mutex> lock(mutex_);
        
        // Check if key already exists
        for (auto& slot : slots_) {
            if (slot && slot->key == entry->key) {
                slot->value = entry->value; // Update existing
                slot->record_access();
                return true;
            }
        }
        
        // Find empty slot or evict from end
        for (size_t i = 0; i < Config::BUCKET_SIZE; ++i) {
            if (!slots_[i]) {
                slots_[i] = std::move(entry);
                size_.fetch_add(1, std::memory_order_relaxed);
                return true;
            }
        }
        
        // Evict last slot (lowest rank)
        slots_[Config::BUCKET_SIZE - 1] = std::move(entry);
        return true;
    }
    
    // Promote entry on access (Dragonfly's rank promotion)
    void promote_on_access(const std::string& key) {
        std::lock_guard<std::mutex> lock(mutex_);
        
        for (size_t i = 1; i < Config::BUCKET_SIZE; ++i) {
            if (slots_[i] && slots_[i]->key == key) {
                // Swap with higher rank slot
                std::swap(slots_[i], slots_[i-1]);
                break;
            }
        }
    }
    
    // Remove entry
    bool remove(const std::string& key) {
        std::lock_guard<std::mutex> lock(mutex_);
        
        for (size_t i = 0; i < Config::BUCKET_SIZE; ++i) {
            if (slots_[i] && slots_[i]->key == key) {
                slots_[i] = nullptr;
                size_.fetch_sub(1, std::memory_order_relaxed);
                
                // Shift remaining entries
                for (size_t j = i; j < Config::BUCKET_SIZE - 1; ++j) {
                    slots_[j] = std::move(slots_[j + 1]);
                }
                return true;
            }
        }
        return false;
    }
    
    size_t size() const {
        return size_.load(std::memory_order_relaxed);
    }
    
    bool is_full() const {
        return size() >= Config::BUCKET_SIZE;
    }
    
    // Get eviction candidate (lowest rank)
    std::unique_ptr<DashEntry> get_eviction_candidate() {
        std::lock_guard<std::mutex> lock(mutex_);
        if (slots_[Config::BUCKET_SIZE - 1]) {
            auto entry = std::move(slots_[Config::BUCKET_SIZE - 1]);
            size_.fetch_sub(1, std::memory_order_relaxed);
            return entry;
        }
        return nullptr;
    }
};

// Segment containing regular and stash buckets
class DashSegment {
private:
    std::array<DashBucket, Config::SEGMENT_SIZE> regular_buckets_;
    std::array<DashBucket, Config::STASH_SIZE> stash_buckets_;
    std::atomic<size_t> total_size_{0};
    std::atomic<bool> needs_split_{false};
    
public:
    DashSegment() = default;
    
    // Find entry in segment
    DashEntry* find(const std::string& key, uint64_t hash) {
        auto [bucket1, bucket2] = DashHash::bucket_ids(hash);
        
        // Check regular buckets first
        if (auto* entry = regular_buckets_[bucket1].find(key)) {
            return entry;
        }
        if (auto* entry = regular_buckets_[bucket2].find(key)) {
            return entry;
        }
        
        // Check stash buckets
        for (auto& stash : stash_buckets_) {
            if (auto* entry = stash.find(key)) {
                return entry;
            }
        }
        
        return nullptr;
    }
    
    // Insert entry into segment
    bool insert(std::unique_ptr<DashEntry> entry) {
        auto [bucket1, bucket2] = DashHash::bucket_ids(entry->hash_value);
        
        // Try regular buckets first
        if (!regular_buckets_[bucket1].is_full()) {
            bool success = regular_buckets_[bucket1].insert(std::move(entry));
            if (success) {
                total_size_.fetch_add(1, std::memory_order_relaxed);
                return true;
            }
        }
        
        if (!regular_buckets_[bucket2].is_full()) {
            bool success = regular_buckets_[bucket2].insert(std::move(entry));
            if (success) {
                total_size_.fetch_add(1, std::memory_order_relaxed);
                return true;
            }
        }
        
        // Try stash buckets
        for (auto& stash : stash_buckets_) {
            if (!stash.is_full()) {
                bool success = stash.insert(std::move(entry));
                if (success) {
                    total_size_.fetch_add(1, std::memory_order_relaxed);
                    entry->is_probationary.store(true); // Stash = probationary
                    return true;
                }
            }
        }
        
        // Segment is full - trigger split
        needs_split_.store(true, std::memory_order_relaxed);
        return false;
    }
    
    // Remove entry from segment
    bool remove(const std::string& key, uint64_t hash) {
        auto [bucket1, bucket2] = DashHash::bucket_ids(hash);
        
        if (regular_buckets_[bucket1].remove(key) || regular_buckets_[bucket2].remove(key)) {
            total_size_.fetch_sub(1, std::memory_order_relaxed);
            return true;
        }
        
        for (auto& stash : stash_buckets_) {
            if (stash.remove(key)) {
                total_size_.fetch_sub(1, std::memory_order_relaxed);
                return true;
            }
        }
        
        return false;
    }
    
    // Promote entry from stash to regular bucket (2Q algorithm)
    void promote_from_probationary(const std::string& key, uint64_t hash) {
        auto [bucket1, bucket2] = DashHash::bucket_ids(hash);
        
        // Find in stash buckets
        for (auto& stash : stash_buckets_) {
            if (auto* entry = stash.find(key)) {
                if (entry->should_promote()) {
                    // Move to regular bucket (protected buffer)
                    auto promoted_entry = std::make_unique<DashEntry>(std::move(*entry));
                    promoted_entry->is_probationary.store(false);
                    
                    stash.remove(key);
                    
                    // Try to insert in regular buckets
                    if (!regular_buckets_[bucket1].is_full()) {
                        regular_buckets_[bucket1].insert(std::move(promoted_entry));
                    } else if (!regular_buckets_[bucket2].is_full()) {
                        regular_buckets_[bucket2].insert(std::move(promoted_entry));
                    } else {
                        // Demote an entry from regular bucket
                        auto demoted = regular_buckets_[bucket1].get_eviction_candidate();
                        if (demoted) {
                            demoted->is_probationary.store(true);
                            stash_buckets_[0].insert(std::move(demoted));
                        }
                        regular_buckets_[bucket1].insert(std::move(promoted_entry));
                    }
                    break;
                }
            }
        }
    }
    
    size_t size() const {
        return total_size_.load(std::memory_order_relaxed);
    }
    
    bool needs_split() const {
        return needs_split_.load(std::memory_order_relaxed);
    }
    
    void clear_split_flag() {
        needs_split_.store(false, std::memory_order_relaxed);
    }
    
    // Get load factor for this segment
    double load_factor() const {
        size_t max_capacity = (Config::SEGMENT_SIZE + Config::STASH_SIZE) * Config::BUCKET_SIZE;
        return static_cast<double>(size()) / max_capacity;
    }
};

// Main Dashtable implementation
class DashTable {
private:
    std::vector<std::unique_ptr<DashSegment>> segments_;
    std::atomic<size_t> segment_count_{Config::INITIAL_SEGMENTS};
    std::atomic<size_t> total_entries_{0};
    mutable std::shared_mutex resize_mutex_; // For segment expansion
    
public:
    DashTable() {
        segments_.reserve(Config::INITIAL_SEGMENTS * 2); // Allow for growth
        for (size_t i = 0; i < Config::INITIAL_SEGMENTS; ++i) {
            segments_.emplace_back(std::make_unique<DashSegment>());
        }
    }
    
    // Get entry by key
    std::string get(const std::string& key) {
        uint64_t hash = DashHash::hash(key);
        uint32_t segment_id = DashHash::segment_id(hash, segment_count_.load());
        
        std::shared_lock<std::shared_mutex> lock(resize_mutex_);
        
        if (segment_id >= segments_.size()) {
            return ""; // Key not found
        }
        
        auto* entry = segments_[segment_id]->find(key, hash);
        if (entry) {
            // Trigger promotion if in probationary buffer
            if (entry->is_probationary.load()) {
                segments_[segment_id]->promote_from_probationary(key, hash);
            } else {
                segments_[segment_id]->promote_on_access(key); // Rank promotion
            }
            return entry->value;
        }
        
        return ""; // Key not found
    }
    
    // Set key-value pair
    bool set(const std::string& key, const std::string& value) {
        uint64_t hash = DashHash::hash(key);
        uint32_t segment_id = DashHash::segment_id(hash, segment_count_.load());
        
        std::shared_lock<std::shared_mutex> lock(resize_mutex_);
        
        if (segment_id >= segments_.size()) {
            return false;
        }
        
        auto entry = std::make_unique<DashEntry>(key, value, hash);
        bool success = segments_[segment_id]->insert(std::move(entry));
        
        if (success) {
            total_entries_.fetch_add(1, std::memory_order_relaxed);
            
            // Check if segment needs splitting
            if (segments_[segment_id]->needs_split()) {
                // Trigger background split (simplified for now)
                segments_[segment_id]->clear_split_flag();
            }
        }
        
        return success;
    }
    
    // Delete key
    bool del(const std::string& key) {
        uint64_t hash = DashHash::hash(key);
        uint32_t segment_id = DashHash::segment_id(hash, segment_count_.load());
        
        std::shared_lock<std::shared_mutex> lock(resize_mutex_);
        
        if (segment_id >= segments_.size()) {
            return false;
        }
        
        bool success = segments_[segment_id]->remove(key, hash);
        if (success) {
            total_entries_.fetch_sub(1, std::memory_order_relaxed);
        }
        
        return success;
    }
    
    // Check if key exists
    bool exists(const std::string& key) {
        uint64_t hash = DashHash::hash(key);
        uint32_t segment_id = DashHash::segment_id(hash, segment_count_.load());
        
        std::shared_lock<std::shared_mutex> lock(resize_mutex_);
        
        if (segment_id >= segments_.size()) {
            return false;
        }
        
        return segments_[segment_id]->find(key, hash) != nullptr;
    }
    
    // Get statistics
    size_t size() const {
        return total_entries_.load(std::memory_order_relaxed);
    }
    
    size_t segment_count() const {
        return segment_count_.load(std::memory_order_relaxed);
    }
    
    double average_load_factor() const {
        std::shared_lock<std::shared_mutex> lock(resize_mutex_);
        double total_load = 0.0;
        for (const auto& segment : segments_) {
            total_load += segment->load_factor();
        }
        return total_load / segments_.size();
    }
};

} // namespace flashdb