#pragma once

#include "flashdb_config.hpp"
#include "resp_protocol.hpp"
#include "thread_pool.hpp"
#include <memory>
#include <atomic>
#include <unordered_map>
#include <chrono>

// Platform-specific includes
#ifdef __APPLE__
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <sys/event.h>  // kqueue on macOS
    #include <unistd.h>
    #include <fcntl.h>
    #include <errno.h>
#else
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <sys/epoll.h>
    #include <unistd.h>
    #include <fcntl.h>
    #include <errno.h>
#endif

namespace flashdb {

// Connection state
struct Connection {
    int fd;
    std::string read_buffer;
    std::string write_buffer;
    size_t bytes_read = 0;
    size_t bytes_written = 0;
    bool keep_alive = true;
    std::chrono::steady_clock::time_point last_activity;
    
    Connection(int socket_fd) : fd(socket_fd), last_activity(std::chrono::steady_clock::now()) {}
};

// High-performance network server (epoll-based, Dragonfly-inspired)
class NetworkServer {
private:
    int listen_fd_;
    int epoll_fd_;
    std::atomic<bool> running_{false};
    RuntimeConfig config_;
    
    // Connection management
    std::unordered_map<int, std::unique_ptr<Connection>> connections_;
    std::mutex connections_mutex_;
    
    // Thread pool and shard manager
    std::unique_ptr<ShardManager> shard_manager_;
    std::unique_ptr<CommandProcessor> command_processor_;
    
    // Statistics
    std::atomic<uint64_t> total_connections_{0};
    std::atomic<uint64_t> total_commands_{0};
    std::atomic<uint64_t> total_bytes_read_{0};
    std::atomic<uint64_t> total_bytes_written_{0};
    
public:
    explicit NetworkServer(const RuntimeConfig& config)
        : config_(config) {
        
        shard_manager_ = std::make_unique<ShardManager>(config_.thread_count);
        // command_processor_ will be created after DashTable is available
    }
    
    ~NetworkServer() {
        stop();
    }
    
    // Start server
    bool start() {
        if (running_.load()) {
            return false;
        }
        
        // Create listening socket
        listen_fd_ = socket(AF_INET, SOCK_STREAM, 0);
        if (listen_fd_ < 0) {
            return false;
        }
        
        // Set socket options
        int opt = 1;
        setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        
        // Make socket non-blocking
        set_non_blocking(listen_fd_);
        
        // Bind socket
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(config_.port);
        addr.sin_addr.s_addr = INADDR_ANY;
        
        if (bind(listen_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
            close(listen_fd_);
            return false;
        }
        
        // Listen for connections
        if (listen(listen_fd_, SOMAXCONN) < 0) {
            close(listen_fd_);
            return false;
        }
        
        // Create epoll instance
        epoll_fd_ = epoll_create1(EPOLL_CLOEXEC);
        if (epoll_fd_ < 0) {
            close(listen_fd_);
            return false;
        }
        
        // Add listen socket to epoll
        epoll_event event{};
        event.events = EPOLLIN | EPOLLET; // Edge-triggered
        event.data.fd = listen_fd_;
        
        if (epoll_ctl(epoll_fd_, EPOLL_CTL_ADD, listen_fd_, &event) < 0) {
            close(epoll_fd_);
            close(listen_fd_);
            return false;
        }
        
        running_.store(true);
        return true;
    }
    
    // Stop server
    void stop() {
        if (!running_.load()) {
            return;
        }
        
        running_.store(false);
        
        // Close all connections
        {
            std::lock_guard<std::mutex> lock(connections_mutex_);
            for (auto& [fd, conn] : connections_) {
                close(fd);
            }
            connections_.clear();
        }
        
        // Close server sockets
        if (epoll_fd_ >= 0) {
            close(epoll_fd_);
        }
        if (listen_fd_ >= 0) {
            close(listen_fd_);
        }
        
        // Shutdown shard manager
        if (shard_manager_) {
            shard_manager_->shutdown();
        }
    }
    
    // Main event loop
    void run() {
        if (!running_.load()) {
            return;
        }
        
        const int max_events = 1024;
        epoll_event events[max_events];
        
        while (running_.load()) {
            int event_count = epoll_wait(epoll_fd_, events, max_events, 100); // 100ms timeout
            
            if (event_count < 0) {
                if (errno == EINTR) {
                    continue;
                }
                break;
            }
            
            for (int i = 0; i < event_count; ++i) {
                if (events[i].data.fd == listen_fd_) {
                    // Accept new connections
                    accept_connections();
                } else {
                    // Handle client data
                    handle_client_event(events[i]);
                }
            }
            
            // Cleanup idle connections periodically
            cleanup_idle_connections();
        }
    }
    
    // Get server statistics
    struct Statistics {
        uint64_t total_connections;
        uint64_t active_connections;
        uint64_t total_commands;
        uint64_t total_bytes_read;
        uint64_t total_bytes_written;
        size_t total_keys;
        size_t shard_count;
    };
    
    Statistics get_statistics() const {
        Statistics stats;
        stats.total_connections = total_connections_.load();
        stats.total_commands = total_commands_.load();
        stats.total_bytes_read = total_bytes_read_.load();
        stats.total_bytes_written = total_bytes_written_.load();
        stats.total_keys = shard_manager_ ? shard_manager_->total_size() : 0;
        stats.shard_count = shard_manager_ ? shard_manager_->shard_count() : 0;
        
        {
            std::lock_guard<std::mutex> lock(connections_mutex_);
            stats.active_connections = connections_.size();
        }
        
        return stats;
    }
    
private:
    void set_non_blocking(int fd) {
        int flags = fcntl(fd, F_GETFL, 0);
        fcntl(fd, F_SETFL, flags | O_NONBLOCK);
    }
    
    void accept_connections() {
        while (true) {
            sockaddr_in client_addr{};
            socklen_t client_len = sizeof(client_addr);
            
            int client_fd = accept(listen_fd_, reinterpret_cast<sockaddr*>(&client_addr), &client_len);
            if (client_fd < 0) {
                if (errno == EAGAIN || errno == EWOULDBLOCK) {
                    break; // No more connections
                }
                continue;
            }
            
            // Set client socket non-blocking
            set_non_blocking(client_fd);
            
            // Add to epoll
            epoll_event event{};
            event.events = EPOLLIN | EPOLLET; // Edge-triggered
            event.data.fd = client_fd;
            
            if (epoll_ctl(epoll_fd_, EPOLL_CTL_ADD, client_fd, &event) < 0) {
                close(client_fd);
                continue;
            }
            
            // Create connection object
            {
                std::lock_guard<std::mutex> lock(connections_mutex_);
                connections_[client_fd] = std::make_unique<Connection>(client_fd);
            }
            
            total_connections_.fetch_add(1);
        }
    }
    
    void handle_client_event(const epoll_event& event) {
        int fd = event.data.fd;
        
        std::unique_ptr<Connection>* conn_ptr = nullptr;
        {
            std::lock_guard<std::mutex> lock(connections_mutex_);
            auto it = connections_.find(fd);
            if (it == connections_.end()) {
                return;
            }
            conn_ptr = &it->second;
        }
        
        Connection& conn = **conn_ptr;
        conn.last_activity = std::chrono::steady_clock::now();
        
        if (event.events & EPOLLIN) {
            handle_read(conn);
        }
        
        if (event.events & EPOLLOUT) {
            handle_write(conn);
        }
        
        if (event.events & (EPOLLHUP | EPOLLERR)) {
            close_connection(fd);
        }
    }
    
    void handle_read(Connection& conn) {
        char buffer[Config::NETWORK_BUFFER_SIZE];
        
        while (true) {
            ssize_t bytes = read(conn.fd, buffer, sizeof(buffer));
            
            if (bytes > 0) {
                conn.read_buffer.append(buffer, bytes);
                conn.bytes_read += bytes;
                total_bytes_read_.fetch_add(bytes);
            } else if (bytes == 0) {
                // Connection closed by client
                close_connection(conn.fd);
                return;
            } else {
                if (errno == EAGAIN || errno == EWOULDBLOCK) {
                    break; // No more data
                }
                close_connection(conn.fd);
                return;
            }
        }
        
        // Process complete commands
        process_commands(conn);
    }
    
    void handle_write(Connection& conn) {
        if (conn.write_buffer.empty()) {
            return;
        }
        
        while (!conn.write_buffer.empty()) {
            ssize_t bytes = write(conn.fd, 
                                conn.write_buffer.data() + conn.bytes_written,
                                conn.write_buffer.size() - conn.bytes_written);
            
            if (bytes > 0) {
                conn.bytes_written += bytes;
                total_bytes_written_.fetch_add(bytes);
                
                if (conn.bytes_written >= conn.write_buffer.size()) {
                    conn.write_buffer.clear();
                    conn.bytes_written = 0;
                    break;
                }
            } else if (bytes == 0) {
                close_connection(conn.fd);
                return;
            } else {
                if (errno == EAGAIN || errno == EWOULDBLOCK) {
                    break; // Would block
                }
                close_connection(conn.fd);
                return;
            }
        }
    }
    
    void process_commands(Connection& conn) {
        size_t pos = 0;
        
        while (pos < conn.read_buffer.size()) {
            auto [command, consumed] = RespProtocol::parse_command(
                conn.read_buffer.data() + pos, 
                conn.read_buffer.size() - pos
            );
            
            if (consumed == 0) {
                break; // Incomplete command
            }
            
            // Process command asynchronously
            total_commands_.fetch_add(1);
            
            // For simplicity, process synchronously here
            // In real implementation, this would be async
            if (command_processor_) {
                RespResponse response = command_processor_->process_command(command);
                std::string response_str = RespProtocol::serialize_response(response);
                conn.write_buffer += response_str;
                
                // Enable write events
                epoll_event event{};
                event.events = EPOLLIN | EPOLLOUT | EPOLLET;
                event.data.fd = conn.fd;
                epoll_ctl(epoll_fd_, EPOLL_CTL_MOD, conn.fd, &event);
            }
            
            pos += consumed;
        }
        
        // Remove processed data
        if (pos > 0) {
            conn.read_buffer.erase(0, pos);
        }
    }
    
    void close_connection(int fd) {
        epoll_ctl(epoll_fd_, EPOLL_CTL_DEL, fd, nullptr);
        close(fd);
        
        {
            std::lock_guard<std::mutex> lock(connections_mutex_);
            connections_.erase(fd);
        }
    }
    
    void cleanup_idle_connections() {
        auto now = std::chrono::steady_clock::now();
        const auto timeout = std::chrono::seconds(300); // 5 minutes
        
        std::vector<int> to_close;
        
        {
            std::lock_guard<std::mutex> lock(connections_mutex_);
            for (const auto& [fd, conn] : connections_) {
                if (now - conn->last_activity > timeout) {
                    to_close.push_back(fd);
                }
            }
        }
        
        for (int fd : to_close) {
            close_connection(fd);
        }
    }
};

} // namespace flashdb