# FlashDB - High-Performance Cache Server

FlashDB is a high-performance, Redis-compatible cache server inspired by Dragonfly's architecture. It implements modern storage techniques including Dashtable, LFRU cache policy, and **io_uring** for maximum performance.

## 🚀 Why io_uring? (Dragonfly's Secret Weapon)

FlashDB uses **io_uring** instead of traditional epoll, just like Dragonfly, for several critical performance advantages:

### Performance Comparison: io_uring vs epoll

| Feature | epoll | io_uring | Advantage |
|---------|-------|----------|-----------|
| **System Calls** | One per operation | Batched operations | **5-10x fewer syscalls** |
| **Latency** | ~10-50μs | ~2-10μs | **2-5x lower latency** |
| **Throughput** | ~200K ops/sec | ~500K+ ops/sec | **2.5x higher throughput** |
| **CPU Efficiency** | High context switching | Minimal context switching | **30-50% less CPU usage** |
| **Memory Copies** | Multiple copies | Zero-copy operations | **Eliminates copy overhead** |
| **Async File I/O** | Not supported | Full support | **True async everything** |

### Why This Matters for Cache Performance

1. **Zero System Call Overhead**: io_uring uses shared ring buffers between userspace and kernel, eliminating the need for system calls on the hot path.

2. **Batch Processing**: Multiple I/O operations can be submitted and completed in a single kernel interaction, dramatically reducing overhead.

3. **True Async I/O**: Unlike epoll (which only handles network readiness), io_uring supports async operations for files, sockets, and other I/O.

4. **Memory Efficiency**: Zero-copy operations reduce memory bandwidth usage and improve cache locality.

## 🏗️ Architecture

FlashDB implements Dragonfly's core architectural innovations:

### 1. **Dashtable Storage**
- Segment-based hash table with 56 regular buckets + 4 stash buckets per segment
- Eliminates traditional hash table resize operations
- Better memory locality and cache performance

### 2. **LFRU (2Q) Cache Policy** 
- Probationary buffer (stash buckets) for new entries
- Protected buffer (regular buckets) for proven entries
- Zero memory overhead per entry
- Resistant to cache pollution

### 3. **Shared-Nothing Architecture**
- One thread per shard, no locks in hot path
- CPU affinity for optimal cache utilization
- Linear scalability with core count

### 4. **io_uring Event Loop**
- Batched I/O operations
- Zero-copy data movement
- Async file and network operations

## 🔧 Building FlashDB

### Prerequisites

**Linux (Recommended for io_uring):**
```bash
# Ubuntu/Debian
sudo apt-get install build-essential cmake liburing-dev

# CentOS/RHEL
sudo yum install gcc-c++ cmake liburing-devel
```

**macOS (epoll fallback):**
```bash
brew install cmake
# Note: io_uring not available on macOS, will use epoll fallback
```

### Build

```bash
git clone <repository>
cd flashDB
chmod +x build.sh
./build.sh
```

This will build:
- `flashdb_server` - Basic epoll-based server (cross-platform)
- `flashdb_iouring_server` - High-performance io_uring server (Linux only)
- `flashdb_benchmark` - Performance benchmark suite
- `flashdb_test` - Unit test suite

## 🚀 Running FlashDB

### Start the io_uring Server (Recommended)
```bash
./build/flashdb_iouring_server -p 6380 -t 16
```

### Start the epoll Server (Fallback)
```bash
./build/flashdb_server -p 6380 -t 16
```

### Command Line Options
```
-p, --port PORT        Server port (default: 6380)
-b, --bind ADDRESS     Bind address (default: 127.0.0.1)
-t, --threads COUNT    Worker threads (default: 8)
-m, --memory BYTES     Memory limit (default: 2GB)
-h, --help            Show help
```

## 📊 Benchmarking

### Run Dragonfly Comparison Benchmarks
```bash
./build/flashdb_benchmark
```

This runs comprehensive benchmarks comparing FlashDB against Dragonfly's performance targets:

1. **Pure GET Operations**: Target 200K+ ops/sec
2. **Pure SET Operations**: Target 150K+ ops/sec  
3. **Mixed Workload (80/20)**: Target 180K+ ops/sec
4. **High Concurrency**: 32 threads scalability test
5. **Small Values**: Optimized for 64-byte values

### Quick Development Test
```bash
./build/flashdb_benchmark --quick
```

### Redis Benchmark Compatibility
```bash
# Test with redis-benchmark
redis-benchmark -h 127.0.0.1 -p 6380 -n 100000 -c 50 -t get,set
```

## 🔌 Redis Compatibility

FlashDB implements the Redis RESP protocol and supports:

### Basic Operations
- `GET key` - Get value by key
- `SET key value` - Set key-value pair
- `DEL key [key ...]` - Delete keys
- `EXISTS key [key ...]` - Check if keys exist
- `PING [message]` - Ping server

### Multi-Key Operations  
- `MGET key [key ...]` - Get multiple values
- `MSET key value [key value ...]` - Set multiple key-value pairs

### Numeric Operations
- `INCR key` - Increment integer value
- `DECR key` - Decrement integer value

### Server Operations
- `INFO` - Get server information
- `FLUSHALL` - Clear all data (planned)

## 🔍 Performance Analysis

### Expected Performance (Linux with io_uring)

| Operation | Throughput | Latency (P99) |
|-----------|------------|---------------|
| GET | 400K+ ops/sec | <5μs |
| SET | 300K+ ops/sec | <10μs |
| Mixed (80/20) | 350K+ ops/sec | <8μs |

### Performance Factors

1. **io_uring Advantage**: 2-5x performance improvement over epoll
2. **Dashtable Efficiency**: Better memory locality than traditional hash tables
3. **LFRU Cache Policy**: Higher hit rates, less cache pollution
4. **Shared-Nothing Design**: Linear scalability, no lock contention
5. **SIMD Optimizations**: Vectorized operations where possible

## 🧪 Testing

Run the test suite:
```bash
./build/flashdb_test
```

Tests cover:
- Dashtable basic operations and collision handling
- LFRU cache policy behavior
- RESP protocol parsing and serialization
- Command processing
- Concurrent operations

## 🎯 Roadmap

### Phase 1: Core Implementation ✅
- [x] Dashtable implementation
- [x] LFRU cache policy
- [x] RESP protocol support
- [x] io_uring integration
- [x] Basic Redis commands

### Phase 2: Performance Optimization (In Progress)
- [ ] SIMD-optimized hash functions
- [ ] Memory pool optimization
- [ ] Advanced batching strategies
- [ ] CPU affinity tuning

### Phase 3: Advanced Features
- [ ] Persistence and recovery
- [ ] Clustering and sharding
- [ ] Advanced data structures (Lists, Sets, Sorted Sets)
- [ ] Pub/Sub support
- [ ] Lua scripting

### Phase 4: Enterprise Features
- [ ] TLS/SSL support
- [ ] Authentication and ACLs
- [ ] Monitoring and metrics
- [ ] Hot configuration reloading

## 🤝 Contributing

FlashDB is designed to be a learning platform for high-performance cache systems. Contributions are welcome!

### Development Setup
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests: `./build/flashdb_test`
5. Run benchmarks: `./build/flashdb_benchmark --quick`
6. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details.

## 🙏 Acknowledgments

FlashDB is inspired by:
- **Dragonfly** - Modern cache architecture and io_uring usage
- **Redis** - Protocol compatibility and API design
- **FASTER** - High-performance storage techniques

---

**Built for Speed. Inspired by Dragonfly. Compatible with Redis.**