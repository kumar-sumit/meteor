#include "../include/dashtable.hpp"
#include "../include/resp_protocol.hpp"
#include <iostream>
#include <cassert>
#include <string>
#include <vector>

namespace flashdb {

class FlashDBTest {
public:
    void run_all_tests() {
        std::cout << "Running FlashDB Test Suite..." << std::endl;
        
        test_dashtable_basic_operations();
        test_dashtable_collision_handling();
        test_dashtable_2q_cache_policy();
        test_resp_protocol_parsing();
        test_resp_protocol_serialization();
        test_command_processing();
        test_concurrent_operations();
        
        std::cout << "All tests passed!" << std::endl;
    }
    
private:
    void test_dashtable_basic_operations() {
        std::cout << "Testing DashTable basic operations..." << std::endl;
        
        DashTable table;
        
        // Test SET and GET
        assert(table.set("key1", "value1"));
        assert(table.get("key1") == "value1");
        
        // Test non-existent key
        assert(table.get("nonexistent") == "");
        
        // Test EXISTS
        assert(table.exists("key1"));
        assert(!table.exists("nonexistent"));
        
        // Test DEL
        assert(table.del("key1"));
        assert(!table.exists("key1"));
        assert(table.get("key1") == "");
        
        // Test multiple keys
        for (int i = 0; i < 100; ++i) {
            std::string key = "test_key_" + std::to_string(i);
            std::string value = "test_value_" + std::to_string(i);
            assert(table.set(key, value));
        }
        
        assert(table.size() == 100);
        
        for (int i = 0; i < 100; ++i) {
            std::string key = "test_key_" + std::to_string(i);
            std::string expected_value = "test_value_" + std::to_string(i);
            assert(table.get(key) == expected_value);
        }
        
        std::cout << "✓ Basic operations test passed" << std::endl;
    }
    
    void test_dashtable_collision_handling() {
        std::cout << "Testing DashTable collision handling..." << std::endl;
        
        DashTable table;
        
        // Insert many keys to force collisions
        const int num_keys = 10000;
        for (int i = 0; i < num_keys; ++i) {
            std::string key = "collision_key_" + std::to_string(i);
            std::string value = "collision_value_" + std::to_string(i);
            assert(table.set(key, value));
        }
        
        // Verify all keys are retrievable
        for (int i = 0; i < num_keys; ++i) {
            std::string key = "collision_key_" + std::to_string(i);
            std::string expected_value = "collision_value_" + std::to_string(i);
            assert(table.get(key) == expected_value);
        }
        
        assert(table.size() == num_keys);
        
        std::cout << "✓ Collision handling test passed" << std::endl;
    }
    
    void test_dashtable_2q_cache_policy() {
        std::cout << "Testing DashTable 2Q cache policy..." << std::endl;
        
        DashTable table;
        
        // Add some keys
        table.set("hot_key_1", "hot_value_1");
        table.set("hot_key_2", "hot_value_2");
        table.set("cold_key_1", "cold_value_1");
        
        // Access hot keys multiple times (should promote them)
        for (int i = 0; i < 5; ++i) {
            table.get("hot_key_1");
            table.get("hot_key_2");
        }
        
        // Access cold key only once
        table.get("cold_key_1");
        
        // All keys should still be retrievable
        assert(table.get("hot_key_1") == "hot_value_1");
        assert(table.get("hot_key_2") == "hot_value_2");
        assert(table.get("cold_key_1") == "cold_value_1");
        
        std::cout << "✓ 2Q cache policy test passed" << std::endl;
    }
    
    void test_resp_protocol_parsing() {
        std::cout << "Testing RESP protocol parsing..." << std::endl;
        
        // Test simple command parsing
        std::string ping_cmd = "*1\r\n$4\r\nPING\r\n";
        auto [cmd1, consumed1] = RespProtocol::parse_command(ping_cmd.data(), ping_cmd.size());
        assert(consumed1 == ping_cmd.size());
        assert(cmd1.command == "PING");
        assert(cmd1.args.empty());
        
        // Test command with arguments
        std::string set_cmd = "*3\r\n$3\r\nSET\r\n$4\r\nkey1\r\n$6\r\nvalue1\r\n";
        auto [cmd2, consumed2] = RespProtocol::parse_command(set_cmd.data(), set_cmd.size());
        assert(consumed2 == set_cmd.size());
        assert(cmd2.command == "SET");
        assert(cmd2.args.size() == 2);
        assert(cmd2.args[0] == "key1");
        assert(cmd2.args[1] == "value1");
        
        // Test incomplete command
        std::string incomplete = "*2\r\n$3\r\nGET\r\n$4\r\nkey";
        auto [cmd3, consumed3] = RespProtocol::parse_command(incomplete.data(), incomplete.size());
        assert(consumed3 == 0); // Should not consume incomplete command
        
        std::cout << "✓ RESP protocol parsing test passed" << std::endl;
    }
    
    void test_resp_protocol_serialization() {
        std::cout << "Testing RESP protocol serialization..." << std::endl;
        
        // Test simple string response
        auto simple = RespProtocol::ok_response();
        std::string serialized = RespProtocol::serialize_response(simple);
        assert(serialized == "+OK\r\n");
        
        // Test bulk string response
        auto bulk = RespProtocol::bulk_string_response("hello world");
        std::string bulk_serialized = RespProtocol::serialize_response(bulk);
        assert(bulk_serialized == "$11\r\nhello world\r\n");
        
        // Test null response
        auto null_resp = RespProtocol::null_response();
        std::string null_serialized = RespProtocol::serialize_response(null_resp);
        assert(null_serialized == "$-1\r\n");
        
        // Test integer response
        auto int_resp = RespProtocol::integer_response(42);
        std::string int_serialized = RespProtocol::serialize_response(int_resp);
        assert(int_serialized == ":42\r\n");
        
        // Test error response
        auto error = RespProtocol::error_response("Something went wrong");
        std::string error_serialized = RespProtocol::serialize_response(error);
        assert(error_serialized == "-Something went wrong\r\n");
        
        std::cout << "✓ RESP protocol serialization test passed" << std::endl;
    }
    
    void test_command_processing() {
        std::cout << "Testing command processing..." << std::endl;
        
        DashTable table;
        CommandProcessor processor(&table);
        
        // Test PING command
        RespCommand ping_cmd("PING", {});
        auto ping_response = processor.process_command(ping_cmd);
        assert(ping_response.type == RespType::SIMPLE_STRING);
        assert(ping_response.data == "PONG");
        
        // Test SET command
        RespCommand set_cmd("SET", {"test_key", "test_value"});
        auto set_response = processor.process_command(set_cmd);
        assert(set_response.type == RespType::SIMPLE_STRING);
        assert(set_response.data == "OK");
        
        // Test GET command
        RespCommand get_cmd("GET", {"test_key"});
        auto get_response = processor.process_command(get_cmd);
        assert(get_response.type == RespType::BULK_STRING);
        assert(get_response.data == "test_value");
        
        // Test GET non-existent key
        RespCommand get_missing_cmd("GET", {"missing_key"});
        auto get_missing_response = processor.process_command(get_missing_cmd);
        assert(get_missing_response.type == RespType::BULK_STRING);
        assert(get_missing_response.data == ""); // Null bulk string
        
        // Test DEL command
        RespCommand del_cmd("DEL", {"test_key"});
        auto del_response = processor.process_command(del_cmd);
        assert(del_response.type == RespType::INTEGER);
        assert(del_response.integer_data == 1);
        
        // Test EXISTS command
        table.set("exists_key", "exists_value");
        RespCommand exists_cmd("EXISTS", {"exists_key", "missing_key"});
        auto exists_response = processor.process_command(exists_cmd);
        assert(exists_response.type == RespType::INTEGER);
        assert(exists_response.integer_data == 1);
        
        std::cout << "✓ Command processing test passed" << std::endl;
    }
    
    void test_concurrent_operations() {
        std::cout << "Testing concurrent operations..." << std::endl;
        
        DashTable table;
        const int num_threads = 8;
        const int ops_per_thread = 1000;
        
        std::vector<std::thread> threads;
        std::atomic<int> success_count{0};
        
        // Launch concurrent threads
        for (int t = 0; t < num_threads; ++t) {
            threads.emplace_back([&table, &success_count, t, ops_per_thread]() {
                for (int i = 0; i < ops_per_thread; ++i) {
                    std::string key = "thread_" + std::to_string(t) + "_key_" + std::to_string(i);
                    std::string value = "thread_" + std::to_string(t) + "_value_" + std::to_string(i);
                    
                    if (table.set(key, value)) {
                        if (table.get(key) == value) {
                            success_count.fetch_add(1);
                        }
                    }
                }
            });
        }
        
        // Wait for all threads
        for (auto& thread : threads) {
            thread.join();
        }
        
        assert(success_count.load() == num_threads * ops_per_thread);
        assert(table.size() == num_threads * ops_per_thread);
        
        std::cout << "✓ Concurrent operations test passed" << std::endl;
    }
};

} // namespace flashdb

int main() {
    flashdb::FlashDBTest test_suite;
    
    try {
        test_suite.run_all_tests();
        std::cout << std::endl << "🎉 All FlashDB tests passed successfully!" << std::endl;
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Test failed with exception: " << e.what() << std::endl;
        return 1;
    } catch (...) {
        std::cerr << "Test failed with unknown exception" << std::endl;
        return 1;
    }
}