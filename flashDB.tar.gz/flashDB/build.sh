#!/bin/bash

# FlashDB Build Script
set -e

echo "Building FlashDB - High-Performance Cache Server"
echo "================================================"

# Create build directory
mkdir -p build
cd build

# Configure with CMake
echo "Configuring with CMake..."
cmake .. -DCMAKE_BUILD_TYPE=Release

# Build the project
echo "Building FlashDB..."
# Detect number of cores (macOS vs Linux)
if command -v nproc >/dev/null 2>&1; then
    CORES=$(nproc)
else
    CORES=$(sysctl -n hw.ncpu 2>/dev/null || echo "4")
fi
make -j$CORES

echo ""
echo "Build complete! Binaries available in build/:"
echo "  flashdb_server    - Main server executable"
echo "  flashdb_benchmark - Performance benchmark suite"
echo "  flashdb_test      - Unit test suite"
echo ""

# Run tests
echo "Running unit tests..."
./flashdb_test

echo ""
echo "✅ FlashDB built successfully and all tests passed!"
echo ""
echo "To run the server:"
echo "  ./flashdb_server --help"
echo ""
echo "To run benchmarks:"
echo "  ./flashdb_benchmark"
echo "  ./flashdb_benchmark --quick  # For quick development testing"