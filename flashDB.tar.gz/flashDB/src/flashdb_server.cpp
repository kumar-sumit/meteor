#include "../include/network_server.hpp"
#include "../include/dashtable.hpp"
#include "../include/resp_protocol.hpp"
#include <iostream>
#include <signal.h>
#include <getopt.h>

namespace flashdb {

// Global server instance for signal handling
NetworkServer* g_server = nullptr;

void signal_handler(int signal) {
    if (g_server && signal == SIGINT) {
        std::cout << "\nShutting down FlashDB server..." << std::endl;
        g_server->stop();
    }
}

void print_usage(const char* program_name) {
    std::cout << "FlashDB - A high-performance cache server inspired by Dragonfly" << std::endl;
    std::cout << "Usage: " << program_name << " [options]" << std::endl;
    std::cout << std::endl;
    std::cout << "Options:" << std::endl;
    std::cout << "  -h, --help              Show this help message" << std::endl;
    std::cout << "  -p, --port PORT         Server port (default: 6380)" << std::endl;
    std::cout << "  -b, --bind ADDRESS      Bind address (default: 127.0.0.1)" << std::endl;
    std::cout << "  -t, --threads COUNT     Number of worker threads (default: 8)" << std::endl;
    std::cout << "  -m, --memory BYTES      Memory limit in bytes (default: 2GB)" << std::endl;
    std::cout << "  -v, --verbose           Enable verbose logging" << std::endl;
    std::cout << std::endl;
    std::cout << "Examples:" << std::endl;
    std::cout << "  " << program_name << " -p 6380 -t 16" << std::endl;
    std::cout << "  " << program_name << " --bind 0.0.0.0 --port 6380 --memory 4294967296" << std::endl;
}

RuntimeConfig parse_arguments(int argc, char* argv[]) {
    RuntimeConfig config;
    
    static struct option long_options[] = {
        {"help",     no_argument,       0, 'h'},
        {"port",     required_argument, 0, 'p'},
        {"bind",     required_argument, 0, 'b'},
        {"threads",  required_argument, 0, 't'},
        {"memory",   required_argument, 0, 'm'},
        {"verbose",  no_argument,       0, 'v'},
        {0, 0, 0, 0}
    };
    
    int option_index = 0;
    int c;
    
    while ((c = getopt_long(argc, argv, "hp:b:t:m:v", long_options, &option_index)) != -1) {
        switch (c) {
            case 'h':
                print_usage(argv[0]);
                exit(0);
                break;
                
            case 'p':
                config.port = static_cast<uint16_t>(std::stoul(optarg));
                break;
                
            case 'b':
                config.bind_address = optarg;
                break;
                
            case 't':
                config.thread_count = std::stoul(optarg);
                break;
                
            case 'm':
                config.memory_limit = std::stoul(optarg);
                break;
                
            case 'v':
                config.log_level = "debug";
                break;
                
            case '?':
                print_usage(argv[0]);
                exit(1);
                break;
                
            default:
                break;
        }
    }
    
    return config;
}

void print_banner() {
    std::cout << R"(
    _____ _           _     ____  ____  
   |  ___| | __ _ ___| |__ |  _ \| __ ) 
   | |_  | |/ _` / __| '_ \| | | |  _ \ 
   |  _| | | (_| \__ \ | | | |_| | |_) |
   |_|   |_|\__,_|___/_| |_|____/|____/ 
                                        
   FlashDB v1.0.0 - High-Performance Cache Server
   Inspired by Dragonfly Architecture
   
)" << std::endl;
}

void print_server_info(const RuntimeConfig& config) {
    std::cout << "Server Configuration:" << std::endl;
    std::cout << "  Bind Address: " << config.bind_address << std::endl;
    std::cout << "  Port: " << config.port << std::endl;
    std::cout << "  Threads: " << config.thread_count << std::endl;
    std::cout << "  Memory Limit: " << (config.memory_limit / (1024 * 1024)) << " MB" << std::endl;
    std::cout << "  Log Level: " << config.log_level << std::endl;
    std::cout << std::endl;
    
    std::cout << "Architecture Features:" << std::endl;
    std::cout << "  ✓ Dashtable with " << Config::SEGMENT_SIZE << " buckets per segment" << std::endl;
    std::cout << "  ✓ LFRU (2Q) cache eviction policy" << std::endl;
    std::cout << "  ✓ Shared-nothing thread architecture" << std::endl;
    std::cout << "  ✓ Redis RESP protocol compatibility" << std::endl;
    std::cout << "  ✓ Epoll-based async I/O" << std::endl;
    std::cout << std::endl;
}

} // namespace flashdb

int main(int argc, char* argv[]) {
    using namespace flashdb;
    
    // Parse command line arguments
    RuntimeConfig config = parse_arguments(argc, argv);
    
    // Print banner and configuration
    print_banner();
    print_server_info(config);
    
    // Set up signal handling
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    
    try {
        // Create and start server
        NetworkServer server(config);
        g_server = &server;
        
        std::cout << "Starting FlashDB server on " << config.bind_address 
                  << ":" << config.port << "..." << std::endl;
        
        if (!server.start()) {
            std::cerr << "Failed to start server!" << std::endl;
            return 1;
        }
        
        std::cout << "FlashDB server started successfully!" << std::endl;
        std::cout << "Ready to accept connections..." << std::endl;
        std::cout << "Press Ctrl+C to shutdown" << std::endl;
        std::cout << std::endl;
        
        // Run server event loop
        server.run();
        
        std::cout << "Server shutdown complete." << std::endl;
        
        // Print final statistics
        auto stats = server.get_statistics();
        std::cout << std::endl;
        std::cout << "Final Statistics:" << std::endl;
        std::cout << "  Total Connections: " << stats.total_connections << std::endl;
        std::cout << "  Total Commands: " << stats.total_commands << std::endl;
        std::cout << "  Total Keys: " << stats.total_keys << std::endl;
        std::cout << "  Bytes Read: " << stats.total_bytes_read << std::endl;
        std::cout << "  Bytes Written: " << stats.total_bytes_written << std::endl;
        
    } catch (const std::exception& e) {
        std::cerr << "Server error: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}