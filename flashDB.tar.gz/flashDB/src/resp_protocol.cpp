#include "../include/resp_protocol.hpp"
#include "../include/dashtable.hpp"
#include <algorithm>
#include <sstream>
#include <cctype>
#include <unistd.h>

namespace flashdb {

RespResponse CommandProcessor::process_command(const RespCommand& command) {
    if (command.command.empty()) {
        return RespProtocol::error_response("ERR empty command");
    }
    
    // Convert command to uppercase for case-insensitive matching
    std::string cmd = command.command;
    std::transform(cmd.begin(), cmd.end(), cmd.begin(), ::toupper);
    
    // Route to appropriate handler
    if (cmd == "PING") {
        return handle_ping(command.args);
    } else if (cmd == "GET") {
        return handle_get(command.args);
    } else if (cmd == "SET") {
        return handle_set(command.args);
    } else if (cmd == "DEL") {
        return handle_del(command.args);
    } else if (cmd == "EXISTS") {
        return handle_exists(command.args);
    } else if (cmd == "MGET") {
        return handle_mget(command.args);
    } else if (cmd == "MSET") {
        return handle_mset(command.args);
    } else if (cmd == "INCR") {
        return handle_incr(command.args);
    } else if (cmd == "DECR") {
        return handle_decr(command.args);
    } else if (cmd == "INFO") {
        return handle_info(command.args);
    } else if (cmd == "FLUSHALL") {
        return handle_flushall(command.args);
    } else {
        return RespProtocol::error_response("ERR unknown command '" + command.command + "'");
    }
}

RespResponse CommandProcessor::handle_ping(const std::vector<std::string>& args) {
    if (args.empty()) {
        return RespResponse(RespType::SIMPLE_STRING, "PONG");
    } else if (args.size() == 1) {
        return RespResponse(RespType::BULK_STRING, args[0]);
    } else {
        return RespProtocol::error_response("ERR wrong number of arguments for 'ping' command");
    }
}

RespResponse CommandProcessor::handle_get(const std::vector<std::string>& args) {
    if (args.size() != 1) {
        return RespProtocol::error_response("ERR wrong number of arguments for 'get' command");
    }
    
    std::string value = table_->get(args[0]);
    if (value.empty()) {
        return RespProtocol::null_response();
    } else {
        return RespProtocol::bulk_string_response(value);
    }
}

RespResponse CommandProcessor::handle_set(const std::vector<std::string>& args) {
    if (args.size() < 2) {
        return RespProtocol::error_response("ERR wrong number of arguments for 'set' command");
    }
    
    const std::string& key = args[0];
    const std::string& value = args[1];
    
    // Handle SET options (simplified - only basic SET for now)
    bool success = table_->set(key, value);
    if (success) {
        return RespProtocol::ok_response();
    } else {
        return RespProtocol::error_response("ERR failed to set key");
    }
}

RespResponse CommandProcessor::handle_del(const std::vector<std::string>& args) {
    if (args.empty()) {
        return RespProtocol::error_response("ERR wrong number of arguments for 'del' command");
    }
    
    int64_t deleted_count = 0;
    for (const std::string& key : args) {
        if (table_->del(key)) {
            deleted_count++;
        }
    }
    
    return RespProtocol::integer_response(deleted_count);
}

RespResponse CommandProcessor::handle_exists(const std::vector<std::string>& args) {
    if (args.empty()) {
        return RespProtocol::error_response("ERR wrong number of arguments for 'exists' command");
    }
    
    int64_t exists_count = 0;
    for (const std::string& key : args) {
        if (table_->exists(key)) {
            exists_count++;
        }
    }
    
    return RespProtocol::integer_response(exists_count);
}

RespResponse CommandProcessor::handle_mget(const std::vector<std::string>& args) {
    if (args.empty()) {
        return RespProtocol::error_response("ERR wrong number of arguments for 'mget' command");
    }
    
    std::vector<RespResponse> results;
    results.reserve(args.size());
    
    for (const std::string& key : args) {
        std::string value = table_->get(key);
        if (value.empty()) {
            results.emplace_back(RespType::BULK_STRING, ""); // Null bulk string
        } else {
            results.emplace_back(RespType::BULK_STRING, value);
        }
    }
    
    return RespResponse(RespType::ARRAY, results);
}

RespResponse CommandProcessor::handle_mset(const std::vector<std::string>& args) {
    if (args.size() % 2 != 0) {
        return RespProtocol::error_response("ERR wrong number of arguments for 'mset' command");
    }
    
    // Set all key-value pairs
    for (size_t i = 0; i < args.size(); i += 2) {
        const std::string& key = args[i];
        const std::string& value = args[i + 1];
        table_->set(key, value);
    }
    
    return RespProtocol::ok_response();
}

RespResponse CommandProcessor::handle_incr(const std::vector<std::string>& args) {
    if (args.size() != 1) {
        return RespProtocol::error_response("ERR wrong number of arguments for 'incr' command");
    }
    
    const std::string& key = args[0];
    std::string current_value = table_->get(key);
    
    int64_t value = 0;
    if (!current_value.empty()) {
        if (!is_integer(current_value)) {
            return RespProtocol::error_response("ERR value is not an integer or out of range");
        }
        value = string_to_integer(current_value);
    }
    
    value++;
    std::string new_value = integer_to_string(value);
    table_->set(key, new_value);
    
    return RespProtocol::integer_response(value);
}

RespResponse CommandProcessor::handle_decr(const std::vector<std::string>& args) {
    if (args.size() != 1) {
        return RespProtocol::error_response("ERR wrong number of arguments for 'decr' command");
    }
    
    const std::string& key = args[0];
    std::string current_value = table_->get(key);
    
    int64_t value = 0;
    if (!current_value.empty()) {
        if (!is_integer(current_value)) {
            return RespProtocol::error_response("ERR value is not an integer or out of range");
        }
        value = string_to_integer(current_value);
    }
    
    value--;
    std::string new_value = integer_to_string(value);
    table_->set(key, new_value);
    
    return RespProtocol::integer_response(value);
}

RespResponse CommandProcessor::handle_info(const std::vector<std::string>& args) {
    // Simplified INFO implementation
    std::ostringstream info;
    info << "# Server\r\n";
    info << "flashdb_version:1.0.0\r\n";
    info << "process_id:" << getpid() << "\r\n";
    info << "tcp_port:6380\r\n";
    info << "\r\n";
    info << "# Memory\r\n";
    info << "used_memory:" << (table_->size() * 100) << "\r\n"; // Rough estimate
    info << "\r\n";
    info << "# Stats\r\n";
    info << "total_keys:" << table_->size() << "\r\n";
    info << "segments:" << table_->segment_count() << "\r\n";
    info << "load_factor:" << table_->average_load_factor() << "\r\n";
    
    return RespProtocol::bulk_string_response(info.str());
}

RespResponse CommandProcessor::handle_flushall(const std::vector<std::string>& args) {
    // For simplicity, we don't implement FLUSHALL in the basic version
    return RespProtocol::error_response("ERR FLUSHALL not implemented yet");
}

bool CommandProcessor::is_integer(const std::string& str) {
    if (str.empty()) {
        return false;
    }
    
    size_t start = 0;
    if (str[0] == '-' || str[0] == '+') {
        start = 1;
    }
    
    if (start >= str.size()) {
        return false;
    }
    
    for (size_t i = start; i < str.size(); ++i) {
        if (!std::isdigit(str[i])) {
            return false;
        }
    }
    
    return true;
}

int64_t CommandProcessor::string_to_integer(const std::string& str) {
    return std::stoll(str);
}

std::string CommandProcessor::integer_to_string(int64_t value) {
    return std::to_string(value);
}

} // namespace flashdb