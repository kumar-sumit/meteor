#include "../include/iouring_server.hpp"
#include "../include/dashtable.hpp"
#include "../include/resp_protocol.hpp"
#include <iostream>
#include <signal.h>
#include <getopt.h>

namespace flashdb {

// Global server instance for signal handling
IOUringServer* g_iouring_server = nullptr;

void iouring_signal_handler(int signal) {
    if (g_iouring_server && signal == SIGINT) {
        std::cout << "\nShutting down FlashDB io_uring server..." << std::endl;
        g_iouring_server->stop();
    }
}

void print_iouring_banner() {
    std::cout << R"(
    _____ _           _     ____  ____        _                   _             
   |  ___| | __ _ ___| |__ |  _ \| __ )      (_) ___         _ __(_)_ __   __ _ 
   | |_  | |/ _` / __| '_ \| | | |  _ \ _____| |/ _ \ _____ | '__| | '_ \ / _` |
   |  _| | | (_| \__ \ | | | |_| | |_) |_____| | (_) |_____| |  | | | | | (_| |
   |_|   |_|\__,_|___/_| |_|____/|____/      |_|\___/      |_|  |_|_| |_|\__, |
                                                                         |___/ 
   FlashDB v1.0.0 - io_uring High-Performance Cache Server
   Dragonfly-Compatible Architecture with io_uring
   
)" << std::endl;
}

void print_iouring_features() {
    std::cout << "io_uring Performance Features:" << std::endl;
    std::cout << "  ✓ Zero-copy I/O operations" << std::endl;
    std::cout << "  ✓ Batch submission/completion" << std::endl;
    std::cout << "  ✓ Shared ring buffers (kernel bypass)" << std::endl;
    std::cout << "  ✓ Async file and socket operations" << std::endl;
    std::cout << "  ✓ ~2-5x lower latency than epoll" << std::endl;
    std::cout << "  ✓ CPU-efficient event processing" << std::endl;
    std::cout << std::endl;
    
    std::cout << "Dragonfly-Compatible Features:" << std::endl;
    std::cout << "  ✓ Dashtable with segment-based storage" << std::endl;
    std::cout << "  ✓ LFRU (2Q) cache eviction policy" << std::endl;
    std::cout << "  ✓ Shared-nothing thread architecture" << std::endl;
    std::cout << "  ✓ Redis RESP protocol compatibility" << std::endl;
    std::cout << "  ✓ Advanced batch processing" << std::endl;
    std::cout << std::endl;
}

} // namespace flashdb

int main(int argc, char* argv[]) {
    using namespace flashdb;
    
    // Parse command line arguments (reuse from regular server)
    RuntimeConfig config;
    config.port = 6380;
    config.thread_count = 8;
    config.bind_address = "127.0.0.1";
    config.memory_limit = 2ULL * 1024 * 1024 * 1024; // 2GB
    
    // Simple argument parsing for demo
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "-p" || arg == "--port") {
            if (i + 1 < argc) {
                config.port = static_cast<uint16_t>(std::stoul(argv[++i]));
            }
        } else if (arg == "-t" || arg == "--threads") {
            if (i + 1 < argc) {
                config.thread_count = std::stoul(argv[++i]);
            }
        } else if (arg == "-h" || arg == "--help") {
            std::cout << "FlashDB io_uring Server" << std::endl;
            std::cout << "Usage: " << argv[0] << " [options]" << std::endl;
            std::cout << "  -p, --port PORT      Server port (default: 6380)" << std::endl;
            std::cout << "  -t, --threads COUNT  Worker threads (default: 8)" << std::endl;
            std::cout << "  -h, --help          Show this help" << std::endl;
            return 0;
        }
    }
    
    // Print banner and features
    print_iouring_banner();
    print_iouring_features();
    
    std::cout << "Server Configuration:" << std::endl;
    std::cout << "  Bind Address: " << config.bind_address << std::endl;
    std::cout << "  Port: " << config.port << std::endl;
    std::cout << "  Threads: " << config.thread_count << std::endl;
    std::cout << "  Memory Limit: " << (config.memory_limit / (1024 * 1024)) << " MB" << std::endl;
    std::cout << std::endl;
    
    // Set up signal handling
    signal(SIGINT, iouring_signal_handler);
    signal(SIGTERM, iouring_signal_handler);
    
    try {
        // Create and start io_uring server
        IOUringServer server(config);
        g_iouring_server = &server;
        
        std::cout << "Starting FlashDB io_uring server on " << config.bind_address 
                  << ":" << config.port << "..." << std::endl;
        
        if (!server.start()) {
            std::cerr << "Failed to start io_uring server!" << std::endl;
            std::cerr << "Note: io_uring requires Linux kernel 5.1+ and liburing" << std::endl;
            return 1;
        }
        
        std::cout << "FlashDB io_uring server started successfully!" << std::endl;
        std::cout << "Using io_uring for maximum performance (Dragonfly-style)" << std::endl;
        std::cout << "Ready to accept connections..." << std::endl;
        std::cout << "Press Ctrl+C to shutdown" << std::endl;
        std::cout << std::endl;
        
        // Run server event loop
        server.run();
        
        std::cout << "Server shutdown complete." << std::endl;
        
        // Print final statistics
        auto stats = server.get_statistics();
        std::cout << std::endl;
        std::cout << "Final Statistics:" << std::endl;
        std::cout << "  Total Connections: " << stats.total_connections << std::endl;
        std::cout << "  Total Commands: " << stats.total_commands << std::endl;
        std::cout << "  Total Keys: " << stats.total_keys << std::endl;
        std::cout << "  Bytes Read: " << stats.total_bytes_read << std::endl;
        std::cout << "  Bytes Written: " << stats.total_bytes_written << std::endl;
        std::cout << "  I/O Operations Submitted: " << stats.io_operations_submitted << std::endl;
        std::cout << "  I/O Operations Completed: " << stats.io_operations_completed << std::endl;
        std::cout << "  I/O Efficiency: " << (stats.io_efficiency * 100) << "%" << std::endl;
        
    } catch (const std::exception& e) {
        std::cerr << "Server error: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}