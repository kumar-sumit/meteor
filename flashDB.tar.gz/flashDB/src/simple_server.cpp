#include "../include/dashtable.hpp"
#include "../include/resp_protocol.hpp"
#include <iostream>
#include <thread>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>

namespace flashdb {

// Simple cross-platform server for demonstration
class SimpleServer {
private:
    int listen_fd_;
    std::atomic<bool> running_{false};
    std::unique_ptr<DashTable> table_;
    std::unique_ptr<CommandProcessor> processor_;
    
public:
    SimpleServer() : table_(std::make_unique<DashTable>()) {
        processor_ = std::make_unique<CommandProcessor>(table_.get());
    }
    
    bool start(uint16_t port) {
        listen_fd_ = socket(AF_INET, SOCK_STREAM, 0);
        if (listen_fd_ < 0) {
            return false;
        }
        
        int opt = 1;
        setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        
        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        addr.sin_addr.s_addr = INADDR_ANY;
        
        if (bind(listen_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
            close(listen_fd_);
            return false;
        }
        
        if (listen(listen_fd_, 128) < 0) {
            close(listen_fd_);
            return false;
        }
        
        running_.store(true);
        return true;
    }
    
    void run() {
        std::cout << "Simple server running (single-threaded demo)" << std::endl;
        
        while (running_.load()) {
            sockaddr_in client_addr{};
            socklen_t client_len = sizeof(client_addr);
            
            int client_fd = accept(listen_fd_, reinterpret_cast<sockaddr*>(&client_addr), &client_len);
            if (client_fd < 0) {
                if (errno == EINTR) continue;
                break;
            }
            
            // Handle client in separate thread for simplicity
            std::thread([this, client_fd]() {
                handle_client(client_fd);
            }).detach();
        }
    }
    
    void stop() {
        running_.store(false);
        if (listen_fd_ >= 0) {
            close(listen_fd_);
        }
    }
    
private:
    void handle_client(int client_fd) {
        char buffer[4096];
        std::string read_buffer;
        
        while (running_.load()) {
            ssize_t bytes = recv(client_fd, buffer, sizeof(buffer), 0);
            if (bytes <= 0) break;
            
            read_buffer.append(buffer, bytes);
            
            // Process commands
            size_t pos = 0;
            while (pos < read_buffer.size()) {
                auto [command, consumed] = RespProtocol::parse_command(
                    read_buffer.data() + pos, read_buffer.size() - pos);
                
                if (consumed == 0) break;
                
                RespResponse response = processor_->process_command(command);
                std::string response_str = RespProtocol::serialize_response(response);
                
                send(client_fd, response_str.data(), response_str.size(), 0);
                pos += consumed;
            }
            
            if (pos > 0) {
                read_buffer.erase(0, pos);
            }
        }
        
        close(client_fd);
    }
};

SimpleServer* g_simple_server = nullptr;

void simple_signal_handler(int signal) {
    if (g_simple_server && signal == SIGINT) {
        std::cout << "\nShutting down simple server..." << std::endl;
        g_simple_server->stop();
    }
}

} // namespace flashdb

int main(int argc, char* argv[]) {
    using namespace flashdb;
    
    uint16_t port = 6380;
    if (argc > 1) {
        port = static_cast<uint16_t>(std::stoul(argv[1]));
    }
    
    std::cout << R"(
    _____ _           _     ____  ____  
   |  ___| | __ _ ___| |__ |  _ \| __ ) 
   | |_  | |/ _` / __| '_ \| | | |  _ \ 
   |  _| | | (_| \__ \ | | | |_| | |_) |
   |_|   |_|\__,_|___/_| |_|____/|____/ 
                                        
   FlashDB v1.0.0 - Simple Demo Server
   Dragonfly-Inspired Architecture (Cross-Platform)
   
)" << std::endl;
    
    signal(SIGINT, simple_signal_handler);
    
    SimpleServer server;
    g_simple_server = &server;
    
    if (!server.start(port)) {
        std::cerr << "Failed to start server on port " << port << std::endl;
        return 1;
    }
    
    std::cout << "FlashDB simple server started on port " << port << std::endl;
    std::cout << "Features:" << std::endl;
    std::cout << "  ✓ Dashtable storage with LFRU cache policy" << std::endl;
    std::cout << "  ✓ Redis RESP protocol compatibility" << std::endl;
    std::cout << "  ✓ Cross-platform support (macOS/Linux)" << std::endl;
    std::cout << std::endl;
    std::cout << "Try: redis-cli -p " << port << " ping" << std::endl;
    std::cout << "Press Ctrl+C to shutdown" << std::endl;
    
    server.run();
    
    std::cout << "Server shutdown complete." << std::endl;
    return 0;
}