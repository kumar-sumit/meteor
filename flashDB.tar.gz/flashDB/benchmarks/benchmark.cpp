#include "../include/dashtable.hpp"
#include "../include/thread_pool.hpp"
#include <iostream>
#include <chrono>
#include <random>
#include <thread>
#include <atomic>
#include <vector>
#include <iomanip>

namespace flashdb {

class FlashDBBenchmark {
private:
    std::unique_ptr<DashTable> table_;
    std::atomic<uint64_t> operations_completed_{0};
    std::atomic<uint64_t> operations_failed_{0};
    std::vector<std::chrono::nanoseconds> latencies_;
    std::mutex latencies_mutex_;
    
public:
    FlashDBBenchmark() : table_(std::make_unique<DashTable>()) {}
    
    struct BenchmarkConfig {
        size_t num_threads = 16;
        size_t operations_per_thread = 100000;
        size_t key_space_size = 1000000;
        size_t value_size = 256;
        double read_ratio = 0.8; // 80% reads, 20% writes
        bool measure_latency = true;
        std::string test_name = "mixed_workload";
    };
    
    struct BenchmarkResults {
        double throughput_ops_per_sec = 0.0;
        double avg_latency_us = 0.0;
        double p50_latency_us = 0.0;
        double p95_latency_us = 0.0;
        double p99_latency_us = 0.0;
        double p999_latency_us = 0.0;
        uint64_t total_operations = 0;
        uint64_t failed_operations = 0;
        double duration_seconds = 0.0;
        size_t final_key_count = 0;
        double load_factor = 0.0;
    };
    
    BenchmarkResults run_benchmark(const BenchmarkConfig& config) {
        std::cout << "Running FlashDB Benchmark: " << config.test_name << std::endl;
        std::cout << "Threads: " << config.num_threads << std::endl;
        std::cout << "Operations per thread: " << config.operations_per_thread << std::endl;
        std::cout << "Key space size: " << config.key_space_size << std::endl;
        std::cout << "Value size: " << config.value_size << " bytes" << std::endl;
        std::cout << "Read ratio: " << (config.read_ratio * 100) << "%" << std::endl;
        std::cout << std::endl;
        
        // Reset counters
        operations_completed_.store(0);
        operations_failed_.store(0);
        latencies_.clear();
        
        // Pre-populate with some data for read operations
        std::cout << "Pre-populating database..." << std::endl;
        pre_populate(config.key_space_size / 2, config.value_size);
        
        // Create worker threads
        std::vector<std::thread> workers;
        workers.reserve(config.num_threads);
        
        auto start_time = std::chrono::high_resolution_clock::now();
        
        // Start benchmark threads
        for (size_t i = 0; i < config.num_threads; ++i) {
            workers.emplace_back([this, &config, i]() {
                worker_thread(config, i);
            });
        }
        
        // Wait for all threads to complete
        for (auto& worker : workers) {
            worker.join();
        }
        
        auto end_time = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::nanoseconds>(end_time - start_time);
        
        // Calculate results
        BenchmarkResults results;
        results.total_operations = operations_completed_.load();
        results.failed_operations = operations_failed_.load();
        results.duration_seconds = duration.count() / 1e9;
        results.throughput_ops_per_sec = results.total_operations / results.duration_seconds;
        results.final_key_count = table_->size();
        results.load_factor = table_->average_load_factor();
        
        // Calculate latency statistics
        if (config.measure_latency && !latencies_.empty()) {
            std::sort(latencies_.begin(), latencies_.end());
            
            auto sum = std::accumulate(latencies_.begin(), latencies_.end(), std::chrono::nanoseconds{0});
            results.avg_latency_us = sum.count() / (latencies_.size() * 1000.0);
            
            size_t size = latencies_.size();
            results.p50_latency_us = latencies_[size * 50 / 100].count() / 1000.0;
            results.p95_latency_us = latencies_[size * 95 / 100].count() / 1000.0;
            results.p99_latency_us = latencies_[size * 99 / 100].count() / 1000.0;
            results.p999_latency_us = latencies_[size * 999 / 1000].count() / 1000.0;
        }
        
        return results;
    }
    
    void print_results(const BenchmarkResults& results) {
        std::cout << std::fixed << std::setprecision(2);
        std::cout << "=== Benchmark Results ===" << std::endl;
        std::cout << "Total Operations: " << results.total_operations << std::endl;
        std::cout << "Failed Operations: " << results.failed_operations << std::endl;
        std::cout << "Duration: " << results.duration_seconds << " seconds" << std::endl;
        std::cout << "Throughput: " << results.throughput_ops_per_sec << " ops/sec" << std::endl;
        std::cout << "Final Key Count: " << results.final_key_count << std::endl;
        std::cout << "Load Factor: " << results.load_factor << std::endl;
        std::cout << std::endl;
        
        if (results.avg_latency_us > 0) {
            std::cout << "Latency Statistics (microseconds):" << std::endl;
            std::cout << "  Average: " << results.avg_latency_us << " μs" << std::endl;
            std::cout << "  P50: " << results.p50_latency_us << " μs" << std::endl;
            std::cout << "  P95: " << results.p95_latency_us << " μs" << std::endl;
            std::cout << "  P99: " << results.p99_latency_us << " μs" << std::endl;
            std::cout << "  P99.9: " << results.p999_latency_us << " μs" << std::endl;
        }
        std::cout << std::endl;
    }
    
    // Run standard Dragonfly-comparable benchmarks
    void run_dragonfly_comparison() {
        std::cout << "=== FlashDB vs Dragonfly Comparison Benchmarks ===" << std::endl;
        std::cout << std::endl;
        
        // Test 1: Pure GET operations (similar to Dragonfly benchmarks)
        {
            BenchmarkConfig config;
            config.test_name = "Pure GET Operations";
            config.num_threads = 16;
            config.operations_per_thread = 100000;
            config.read_ratio = 1.0; // 100% reads
            config.value_size = 256;
            
            auto results = run_benchmark(config);
            print_results(results);
            
            std::cout << "Target: Match Dragonfly's ~200k ops/sec GET performance" << std::endl;
            if (results.throughput_ops_per_sec > 200000) {
                std::cout << "✓ PASSED: Exceeded target performance!" << std::endl;
            } else {
                std::cout << "✗ NEEDS WORK: Below target performance" << std::endl;
            }
            std::cout << std::endl;
        }
        
        // Test 2: Pure SET operations
        {
            BenchmarkConfig config;
            config.test_name = "Pure SET Operations";
            config.num_threads = 16;
            config.operations_per_thread = 100000;
            config.read_ratio = 0.0; // 100% writes
            config.value_size = 256;
            
            auto results = run_benchmark(config);
            print_results(results);
            
            std::cout << "Target: Match Dragonfly's ~150k ops/sec SET performance" << std::endl;
            if (results.throughput_ops_per_sec > 150000) {
                std::cout << "✓ PASSED: Exceeded target performance!" << std::endl;
            } else {
                std::cout << "✗ NEEDS WORK: Below target performance" << std::endl;
            }
            std::cout << std::endl;
        }
        
        // Test 3: Mixed workload (80% reads, 20% writes)
        {
            BenchmarkConfig config;
            config.test_name = "Mixed Workload (80/20)";
            config.num_threads = 16;
            config.operations_per_thread = 100000;
            config.read_ratio = 0.8;
            config.value_size = 256;
            
            auto results = run_benchmark(config);
            print_results(results);
            
            std::cout << "Target: Achieve balanced performance for mixed workloads" << std::endl;
            if (results.throughput_ops_per_sec > 180000) {
                std::cout << "✓ PASSED: Good mixed workload performance!" << std::endl;
            } else {
                std::cout << "✗ NEEDS WORK: Mixed workload needs optimization" << std::endl;
            }
            std::cout << std::endl;
        }
        
        // Test 4: High concurrency test
        {
            BenchmarkConfig config;
            config.test_name = "High Concurrency (32 threads)";
            config.num_threads = 32;
            config.operations_per_thread = 50000;
            config.read_ratio = 0.8;
            config.value_size = 256;
            
            auto results = run_benchmark(config);
            print_results(results);
            
            std::cout << "Target: Scale well with high concurrency" << std::endl;
            if (results.throughput_ops_per_sec > 200000) {
                std::cout << "✓ PASSED: Good scalability!" << std::endl;
            } else {
                std::cout << "✗ NEEDS WORK: Scalability needs improvement" << std::endl;
            }
            std::cout << std::endl;
        }
        
        // Test 5: Small value performance
        {
            BenchmarkConfig config;
            config.test_name = "Small Values (64 bytes)";
            config.num_threads = 16;
            config.operations_per_thread = 100000;
            config.read_ratio = 0.8;
            config.value_size = 64;
            
            auto results = run_benchmark(config);
            print_results(results);
            
            std::cout << "Target: Optimize for small value performance" << std::endl;
            if (results.throughput_ops_per_sec > 220000) {
                std::cout << "✓ PASSED: Excellent small value performance!" << std::endl;
            } else {
                std::cout << "✗ NEEDS WORK: Small value optimization needed" << std::endl;
            }
            std::cout << std::endl;
        }
    }
    
private:
    void pre_populate(size_t key_count, size_t value_size) {
        std::string value(value_size, 'x');
        for (size_t i = 0; i < key_count; ++i) {
            std::string key = "key:" + std::to_string(i);
            table_->set(key, value);
        }
        std::cout << "Pre-populated " << key_count << " keys" << std::endl;
    }
    
    void worker_thread(const BenchmarkConfig& config, size_t thread_id) {
        std::mt19937 rng(thread_id * 42); // Deterministic seed per thread
        std::uniform_int_distribution<size_t> key_dist(0, config.key_space_size - 1);
        std::uniform_real_distribution<double> op_dist(0.0, 1.0);
        
        std::string value(config.value_size, 'a' + (thread_id % 26));
        
        for (size_t i = 0; i < config.operations_per_thread; ++i) {
            std::string key = "key:" + std::to_string(key_dist(rng));
            
            auto start_time = std::chrono::high_resolution_clock::now();
            
            bool success = false;
            if (op_dist(rng) < config.read_ratio) {
                // Read operation
                std::string result = table_->get(key);
                success = true; // GET always succeeds (returns empty if not found)
            } else {
                // Write operation
                success = table_->set(key, value);
            }
            
            auto end_time = std::chrono::high_resolution_clock::now();
            
            if (success) {
                operations_completed_.fetch_add(1);
            } else {
                operations_failed_.fetch_add(1);
            }
            
            // Record latency (sample to avoid memory overhead)
            if (config.measure_latency && (i % 100 == 0)) {
                auto latency = std::chrono::duration_cast<std::chrono::nanoseconds>(end_time - start_time);
                std::lock_guard<std::mutex> lock(latencies_mutex_);
                latencies_.push_back(latency);
            }
        }
    }
};

} // namespace flashdb

int main(int argc, char* argv[]) {
    using namespace flashdb;
    
    std::cout << "FlashDB Performance Benchmark Suite" << std::endl;
    std::cout << "Comparing against Dragonfly baseline performance" << std::endl;
    std::cout << "=========================================" << std::endl;
    std::cout << std::endl;
    
    FlashDBBenchmark benchmark;
    
    if (argc > 1 && std::string(argv[1]) == "--quick") {
        // Quick test for development
        FlashDBBenchmark::BenchmarkConfig config;
        config.test_name = "Quick Test";
        config.num_threads = 4;
        config.operations_per_thread = 10000;
        config.read_ratio = 0.8;
        
        auto results = benchmark.run_benchmark(config);
        benchmark.print_results(results);
    } else {
        // Full Dragonfly comparison suite
        benchmark.run_dragonfly_comparison();
    }
    
    std::cout << "Benchmark complete!" << std::endl;
    return 0;
}