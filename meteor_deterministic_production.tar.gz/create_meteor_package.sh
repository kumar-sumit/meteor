#!/bin/bash

# **METEOR SERVER - PACKAGE CREATION SCRIPT**
# Creates distributable tar.gz package for enterprise deployment
# Similar to Redis/DragonflyDB distribution model

set -euo pipefail

# Package configuration
PACKAGE_NAME="meteor-server"
PACKAGE_VERSION="7.0-deterministic-core-affinity"
BUILD_DATE=$(date +"%Y%m%d")
# Handle help first
if [[ "${1:-}" == "--help" || "${1:-}" == "-h" || "${1:-}" == "help" ]]; then
    show_help() {
        echo "Usage: $0 [UBUNTU_VERSION] [OPTIONS]"
        echo ""
        echo "UBUNTU_VERSION:"
        echo "  22           - Create package for Ubuntu 22"
        echo "  24           - Create package for Ubuntu 24 (default)"
        echo ""
        echo "OPTIMIZATION:"
        echo "  Priority order for binary selection:"
        echo "  1. Pre-built: meteor-server-ubuntu24-avx512 (self-contained distribution)"
        echo "  2. Auto-build AVX-512: cpp/meteor_ttl_complete_ubuntu24 with g++13/C++20" 
        echo "  3. Auto-build AVX2: cpp/meteor_ttl_complete as fallback"
        echo "  - Build requires: meteor_baseline_prod_v4.cpp source file"
        echo ""
        echo "OPTIONS:"
        echo "  --help, -h   - Show this help message"
        echo ""
        echo "ENVIRONMENT:"
        echo "  FORCE_AVX2=1 - Force AVX2 binary even on AVX-512 CPUs"
        echo ""
        echo "EXAMPLES:"
        echo "  $0           - Auto-detect and create Ubuntu 24 package"
        echo "  $0 24        - Ubuntu 24 with auto CPU detection"
        echo "  $0 22        - Ubuntu 22 with auto CPU detection"
        echo "  FORCE_AVX2=1 $0 - Force AVX2 build"
        echo ""
        echo "OUTPUT:"
        echo "  meteor-server-8.1.0-ubuntu\${VERSION}-$(date +"%Y%m%d").tar.gz"
    }
    show_help
    exit 0
fi

UBUNTU_VERSION="${1:-24}"  # Ubuntu version parameter (22 or 24)
PACKAGE_FULL_NAME="${PACKAGE_NAME}-${PACKAGE_VERSION}-ubuntu${UBUNTU_VERSION}-${BUILD_DATE}"
BINARY_NAME="meteor-server"

# Detect CPU AVX-512 support (can be overridden by setting FORCE_AVX2=1)
detect_cpu_capabilities() {
    if [ "${FORCE_AVX2:-0}" = "1" ]; then
        echo "AVX2"
        return
    fi
    
    # Check for AVX-512 support using available tools
    if command -v lscpu >/dev/null 2>&1; then
        if lscpu | grep -q "avx512f"; then
            echo "AVX-512"
            return
        fi
    elif [ -f /proc/cpuinfo ]; then
        if grep -q "avx512f" /proc/cpuinfo; then
            echo "AVX-512"
            return
        fi
    fi
    
    # Default to AVX2 if no AVX-512 detected
    echo "AVX2"
}

CPU_CAPABILITIES=$(detect_cpu_capabilities)

# Default server configuration
DEFAULT_CORES="8"
DEFAULT_SHARDS="8"
DEFAULT_MEMORY="16384"  # MB
DEFAULT_PORT="6379"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Logging functions
log() {
    echo -e "${GREEN}[PACKAGE]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[PACKAGE]${NC} $1"
}

error() {
    echo -e "${RED:-\033[0;31m}[PACKAGE ERROR]${NC} $1"
    exit 1
}

info() {
    echo -e "${BLUE}[PACKAGE]${NC} $1"
}

# Build meteor binary if it doesn't exist
build_meteor_binary() {
    local binary_target="$1"
    local optimization="$2"
    
    if [ -f "$binary_target" ]; then
        info "Binary $binary_target already exists, skipping build"
        return 0
    fi
    
    log "Building $optimization optimized meteor binary..."
    
    # Check for source file - Priority: Deterministic Core Affinity > Persistence > Baseline
    local source_file=""
    if [ -f "cpp/meteor_deterministic_core_affinity.cpp" ]; then
        source_file="cpp/meteor_deterministic_core_affinity.cpp"
        info "Using HIGH-PERFORMANCE DETERMINISTIC source: meteor_deterministic_core_affinity.cpp"
    elif [ -f "meteor_deterministic_core_affinity.cpp" ]; then
        source_file="meteor_deterministic_core_affinity.cpp"
        info "Using HIGH-PERFORMANCE DETERMINISTIC source: meteor_deterministic_core_affinity.cpp"
    elif [ -f "cpp/meteor_v8_persistent_snapshot.cpp" ]; then
        source_file="cpp/meteor_v8_persistent_snapshot.cpp"
        info "Using ENTERPRISE PERSISTENCE source: meteor_v8_persistent_snapshot.cpp"
    elif [ -f "meteor_v8_persistent_snapshot.cpp" ]; then
        source_file="meteor_v8_persistent_snapshot.cpp"
        info "Using ENTERPRISE PERSISTENCE source: meteor_v8_persistent_snapshot.cpp"
    elif [ -f "cpp/meteor_baseline_prod_v4.cpp" ]; then
        source_file="cpp/meteor_baseline_prod_v4.cpp"
        info "Using baseline source: meteor_baseline_prod_v4.cpp"
    elif [ -f "meteor_baseline_prod_v4.cpp" ]; then
        source_file="meteor_baseline_prod_v4.cpp"
        info "Using baseline source: meteor_baseline_prod_v4.cpp"
    else
        error "No source file found. Looking for: meteor_v8_persistent_snapshot.cpp or meteor_baseline_prod_v4.cpp in cpp/ or current directory"
    fi
    
    # Detect compiler
    local compiler="g++"
    if command -v g++-13 >/dev/null 2>&1; then
        compiler="g++-13"
        info "Using g++-13 for C++20 optimizations"
    elif command -v g++ >/dev/null 2>&1; then
        compiler="g++"
        info "Using default g++ compiler"
    else
        error "No suitable C++ compiler found"
    fi
    
    # Base compiler flags for C++20 and performance - Enterprise persistence requires C++20
    local base_flags="-std=c++20 -O3 -DNDEBUG -DHAS_LINUX_EPOLL -pthread -march=native -mtune=native"
    
    # Aggressive SIMD optimization flags matching user specification
    local opt_flags=""
    if [ "$optimization" = "AVX-512" ]; then
        # Full AVX-512: Complete optimization suite as specified by user
        opt_flags="-mavx512f -mavx512dq -mavx2 -mavx -msse4.2 -msse4.1 -mfma"
        log "Using aggressive AVX-512 flags as specified: mavx512f mavx512dq mavx2 mavx msse4.2 msse4.1 mfma"
    else
        # AVX2: Complete optimization suite
        opt_flags="-mavx2 -mavx -msse4.2 -msse4.1 -mfma"
        log "Using aggressive AVX2 flags: mavx2 mavx msse4.2 msse4.1 mfma"
    fi
    
    # Libraries - Include persistence dependencies for Enterprise features
    local libs="-lboost_fiber -lboost_context -lboost_system -luring -ljemalloc -lzstd -llz4 -lssl -lcrypto -lcurl"
    
    log "Compiling with $compiler C++20 Enterprise and $optimization optimizations..."
    log "Source: $source_file -> Target: $binary_target"
    
    # Create cpp directory if it doesn't exist
    mkdir -p cpp
    
    # Compile
    if $compiler $base_flags $opt_flags -o "$binary_target" "$source_file" $libs; then
        log "Successfully built $optimization optimized binary: $binary_target"
        chmod +x "$binary_target"
        
        # Display binary info
        local binary_size=$(du -h "$binary_target" | cut -f1)
        info "Binary size: $binary_size"
        
        return 0
    else
        error "Failed to compile $binary_target with $optimization optimizations"
    fi
}

# Binary source selection and building
setup_binary_source() {
    # Check for configurable production binary first (enterprise v8.3 with configurable snapshots)
    if [ -f "meteor-server-v8.3-production-configurable" ]; then
        BINARY_SOURCE="meteor-server-v8.3-production-configurable"
        OPTIMIZATION_TYPE="C++20-Enterprise-Configurable-Production"
        JEMALLOC_SUPPORT="true"
        log "Using Enterprise v8.3 CONFIGURABLE PRODUCTION binary with all fixes (C++20, persistence, BGSAVE fix, configurable snapshots)"
        info "Binary: $BINARY_SOURCE ($(du -h "$BINARY_SOURCE" | cut -f1)) - Production-ready with BGSAVE + configurable automatic snapshots"
    # Check for complete production binary (fallback)
    elif [ -f "meteor-server-v8.3-production-complete" ]; then
        BINARY_SOURCE="meteor-server-v8.3-production-complete"
        OPTIMIZATION_TYPE="C++20-Enterprise-Complete-Production"
        JEMALLOC_SUPPORT="true"
        log "Using Enterprise v8.3 COMPLETE PRODUCTION binary with all fixes (C++20, persistence, BGSAVE fix, automatic snapshots)"
        info "Binary: $BINARY_SOURCE ($(du -h "$BINARY_SOURCE" | cut -f1)) - Complete production-ready with BGSAVE + automatic snapshot fixes"
    # Check for AOF truncation fixed binary (fallback)
    elif [ -f "meteor-server-v8.2-aof-fixed-production" ]; then
        BINARY_SOURCE="meteor-server-v8.2-aof-fixed-production"
        OPTIMIZATION_TYPE="C++20-Enterprise-AOF-Fixed-Production"
        JEMALLOC_SUPPORT="true"
        log "Using Enterprise v8.2 PRODUCTION binary with AOF truncation fix (C++20, persistence, full SIMD)"
        info "Binary: $BINARY_SOURCE ($(du -h "$BINARY_SOURCE" | cut -f1)) - Production-ready with AOF infinite growth fix"
    # Check for async BGSAVE fixed binary (fallback)
    elif [ -f "meteor-server-v8.2-enterprise-fixed" ]; then
        BINARY_SOURCE="meteor-server-v8.2-enterprise-fixed"
        OPTIMIZATION_TYPE="C++20-Enterprise-AsyncBGSAVE-Fixed"
        JEMALLOC_SUPPORT="true"
        log "Using Enterprise v8.2 binary with Async BGSAVE fix (C++20, persistence, full SIMD)"
        info "Binary: $BINARY_SOURCE ($(du -h "$BINARY_SOURCE" | cut -f1)) - Production-ready with async BGSAVE"
    # Check for new C++17 aggressive v2 binary first (with user-specified flags)
    elif [ -f "meteor-server-cpp17-aggressive-v2" ]; then
        BINARY_SOURCE="meteor-server-cpp17-aggressive-v2"
        OPTIMIZATION_TYPE="C++17-AVX-512-Aggressive-v2"
        JEMALLOC_SUPPORT="true"
        log "Using C++17 aggressive AVX-512 binary v2 (O3, mavx512f mavx512dq mavx2 mavx msse4.2 msse4.1 mfma)"
        info "Binary: $BINARY_SOURCE ($(du -h "$BINARY_SOURCE" | cut -f1)) - User-specified optimization flags"
    # Check for previous C++17 aggressive binary as fallback
    elif [ -f "meteor-server-cpp17-aggressive" ]; then
        BINARY_SOURCE="meteor-server-cpp17-aggressive"
        OPTIMIZATION_TYPE="C++17-AVX-512-Aggressive"
        JEMALLOC_SUPPORT="true"
        log "Using C++17 aggressive AVX-512 binary (O3, march=native, full SIMD)"
        info "Binary: $BINARY_SOURCE ($(du -h "$BINARY_SOURCE" | cut -f1)) - Maximum performance build"
    # Check for pre-built Ubuntu 24 AVX-512 binary as fallback
    elif [ -f "meteor-server-ubuntu24-avx512" ]; then
        BINARY_SOURCE="meteor-server-ubuntu24-avx512"
        OPTIMIZATION_TYPE="AVX-512"
        JEMALLOC_SUPPORT="true"
        log "Using pre-built Ubuntu 24 AVX-512 binary for self-contained distribution"
        info "Binary: $BINARY_SOURCE ($(du -h "$BINARY_SOURCE" | cut -f1)) - No compilation dependencies required"
    elif [ "$CPU_CAPABILITIES" = "AVX-512" ]; then
        BINARY_SOURCE="cpp/meteor_ttl_complete_ubuntu24"
        OPTIMIZATION_TYPE="AVX-512"
        JEMALLOC_SUPPORT="true"
        
        # Build AVX-512 binary if it doesn't exist
        build_meteor_binary "$BINARY_SOURCE" "AVX-512"
    else
        BINARY_SOURCE="cpp/meteor_ttl_complete"
        OPTIMIZATION_TYPE="AVX2"
        JEMALLOC_SUPPORT=$([ "$UBUNTU_VERSION" = "24" ] && echo "true" || echo "optional")
        
        # Build AVX2 binary if it doesn't exist  
        build_meteor_binary "$BINARY_SOURCE" "AVX2"
    fi

    # Final check that binary exists after build attempt
    if [ ! -f "$BINARY_SOURCE" ]; then
        error "Failed to create or find meteor binary at $BINARY_SOURCE"
    fi
    
    # Display configuration summary
    log "Binary configuration complete:"
    info "Optimization: $OPTIMIZATION_TYPE | jemalloc: $JEMALLOC_SUPPORT | Binary: $BINARY_SOURCE"
}

print_banner() {
    cat << 'BANNER'

███╗   ███╗███████╗████████╗███████╗ ██████╗ ██████╗ 
████╗ ████║██╔════╝╚══██╔══╝██╔════╝██╔═══██╗██╔══██╗
██╔████╔██║█████╗     ██║   █████╗  ██║   ██║██████╔╝
██║╚██╔╝██║██╔══╝     ██║   ██╔══╝  ██║   ██║██╔══██╗
██║ ╚═╝ ██║███████╗   ██║   ███████╗╚██████╔╝██║  ██║
╚═╝     ╚═╝╚══════╝   ╚═╝   ╚══════╝ ╚═════╝ ╚═╝  ╚═╝

    DISTRIBUTION PACKAGE BUILDER v8.0
    High-Performance Redis-Compatible Server
    
BANNER

    echo -e "${GREEN}Creating distributable package: ${PACKAGE_FULL_NAME}${NC}"
    echo "Ubuntu Version: $UBUNTU_VERSION | CPU: $CPU_CAPABILITIES"
    echo "=================================================================="
}

# Validate prerequisites
validate_prerequisites() {
    log "Validating prerequisites..."
    
    # Check if binary exists locally
    if [ ! -f "$BINARY_SOURCE" ]; then
        error "Binary not found at $BINARY_SOURCE
        
Detected CPU: $CPU_CAPABILITIES | Ubuntu: $UBUNTU_VERSION

Binary options for package creation:

1. SELF-CONTAINED DISTRIBUTION (Recommended):
   - Place pre-built binary: meteor-server-ubuntu24-avx512
   - No compilation dependencies required
   - Ready for any Ubuntu 24 VM

2. AUTO-BUILD FROM SOURCE:
   - Source file: cpp/meteor_baseline_prod_v4.cpp (or meteor_baseline_prod_v4.cpp)
   - Binaries built automatically:
     * AVX-512: cpp/meteor_ttl_complete_ubuntu24 (if CPU supports AVX-512)
     * AVX2: cpp/meteor_ttl_complete (fallback)

Environment: FORCE_AVX2=1 $0 (force AVX2 build)"
    fi
    
    # Check if binary is executable
    if [ ! -x "$BINARY_SOURCE" ]; then
        error "Binary at $BINARY_SOURCE is not executable. Run: chmod +x $BINARY_SOURCE"
    fi
    
    # Display binary information
    BINARY_SIZE=$(du -h "$BINARY_SOURCE" | cut -f1)
    info "Using binary: $BINARY_SOURCE ($BINARY_SIZE) for Ubuntu $UBUNTU_VERSION"
    
    # Check deployment directory
    if [ ! -d "deployment" ]; then
        error "deployment directory not found. Please run this script from the meteor project root"
    fi
    
    log "Prerequisites validated successfully"
    info "Using binary: $(ls -lh $BINARY_SOURCE)"
}

# Create package directory structure
create_package_structure() {
    log "Creating package directory structure..."
    
    # Clean up any existing package directory
    rm -rf "$PACKAGE_FULL_NAME"
    
    # Create main package directory
    mkdir -p "$PACKAGE_FULL_NAME"
    
    # Create standard directory structure
    mkdir -p "$PACKAGE_FULL_NAME"/{bin,lib,etc,scripts,docs,systemd,monitoring}
    
    log "Package structure created"
}

# Copy and prepare binary
prepare_binary() {
    log "Preparing Meteor server binary..."
    
    # Copy binary with standard name
    cp "$BINARY_SOURCE" "$PACKAGE_FULL_NAME/bin/$BINARY_NAME"
    chmod +x "$PACKAGE_FULL_NAME/bin/$BINARY_NAME"
    
    # Skip library bundling (rely on system packages for Boost libraries)
    log "Skipping library bundling - using system Boost libraries for better compatibility"
    info "Dependencies: libboost-fiber, libboost-context, libboost-system will be installed via apt"
    
    # Get binary info
    BINARY_SIZE=$(du -h "$PACKAGE_FULL_NAME/bin/$BINARY_NAME" | cut -f1)
    info "Binary size: $BINARY_SIZE"
    
    # Create version file
    cat > "$PACKAGE_FULL_NAME/bin/VERSION" << VERSION
METEOR_VERSION=$PACKAGE_VERSION
BUILD_DATE=$BUILD_DATE
BINARY_NAME=$BINARY_NAME
BINARY_SIZE=$BINARY_SIZE
GIT_COMMIT=$(git rev-parse --short HEAD 2>/dev/null || echo "unknown")
BUILD_HOST=$(hostname)
BUILD_USER=$(whoami)
VERSION

    log "Binary prepared successfully"
}

# Copy deployment scripts
copy_deployment_files() {
    log "Copying deployment files..."
    
    # Copy and update main deployment script
    cp deployment/scripts/deploy_meteor.sh "$PACKAGE_FULL_NAME/scripts/"
    
    # Update binary name in deployment script
    sed -i.bak "s/meteor_race_fix/$BINARY_NAME/g" "$PACKAGE_FULL_NAME/scripts/deploy_meteor.sh"
    rm "$PACKAGE_FULL_NAME/scripts/deploy_meteor.sh.bak"
    
    # For Ubuntu 24, add jemalloc support to the systemd service
    if [ "$UBUNTU_VERSION" = "24" ]; then
        log "Configuring jemalloc support for Ubuntu 24..."
        
        # Create a modified service file with jemalloc support
        cp deployment/systemd/meteor.service "$PACKAGE_FULL_NAME/systemd/"
        
        # Add jemalloc environment variable using awk (more portable)
        if ! grep -q "LD_PRELOAD.*libjemalloc" "$PACKAGE_FULL_NAME/systemd/meteor.service"; then
            awk '
                /^\[Service\]/ { 
                    print; 
                    print "Environment=\"LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libjemalloc.so.2\""; 
                    next 
                }
                { print }
            ' "$PACKAGE_FULL_NAME/systemd/meteor.service" > "$PACKAGE_FULL_NAME/systemd/meteor.service.tmp"
            mv "$PACKAGE_FULL_NAME/systemd/meteor.service.tmp" "$PACKAGE_FULL_NAME/systemd/meteor.service"
            info "Added jemalloc LD_PRELOAD to systemd service for Ubuntu 24"
        fi
    else
        # For Ubuntu 22, use standard service file
        cp deployment/systemd/meteor.service "$PACKAGE_FULL_NAME/systemd/"
        info "Using standard systemd service for Ubuntu 22"
    fi
    
    # Copy backup script
    cp deployment/scripts/backup_meteor.sh "$PACKAGE_FULL_NAME/scripts/"
    
    # Copy cleanup script
    if [ -f "cleanup_meteor.sh" ]; then
        cp cleanup_meteor.sh "$PACKAGE_FULL_NAME/scripts/"
        chmod +x "$PACKAGE_FULL_NAME/scripts/cleanup_meteor.sh"
        info "Added cleanup script to package"
    fi
    
    # Copy configuration files
    cp deployment/config/production.conf "$PACKAGE_FULL_NAME/etc/meteor.conf"
    
    # Copy systemd service file
    cp deployment/systemd/meteor.service "$PACKAGE_FULL_NAME/systemd/"
    
    # Copy monitoring configurations
    cp deployment/monitoring/* "$PACKAGE_FULL_NAME/monitoring/"
    
    log "Deployment files copied"
}

# Create installation script
create_install_script() {
    log "Creating installation script..."
    
    cat > "$PACKAGE_FULL_NAME/install.sh" << 'INSTALL_START'
#!/bin/bash

# **METEOR SERVER - INSTALLATION SCRIPT**
# Self-contained installer for Meteor server package

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GREEN='\033[0;32m'
NC='\033[0m'

# Default server configuration
INSTALL_START
    
    # Add the default values with actual substitution
    cat >> "$PACKAGE_FULL_NAME/install.sh" << INSTALL_VALUES
DEFAULT_CORES="8"
DEFAULT_SHARDS="8"
DEFAULT_MEMORY="$DEFAULT_MEMORY"
DEFAULT_PORT="$DEFAULT_PORT"
INSTALL_VALUES
    
    cat >> "$PACKAGE_FULL_NAME/install.sh" << 'INSTALL_REST'

log() {
    echo -e "${GREEN}[INSTALL]${NC} $1"
}

print_banner() {
    cat << 'BANNER'

███╗   ███╗███████╗████████╗███████╗ ██████╗ ██████╗ 
████╗ ████║██╔════╝╚══██╔══╝██╔════╝██╔═══██╗██╔══██╗
██╔████╔██║█████╗     ██║   █████╗  ██║   ██║██████╔╝
██║╚██╔╝██║██╔══╝     ██║   ██╔══╝  ██║   ██║██╔══██╗
██║ ╚═╝ ██║███████╗   ██║   ███████╗╚██████╔╝██║  ██║
╚═╝     ╚═╝╚══════╝   ╚═╝   ╚══════╝ ╚═════╝ ╚═╝  ╚═╝

    METEOR SERVER INSTALLATION
    Enterprise Redis-Compatible Server
    
BANNER
}

show_usage() {
    cat << USAGE
Meteor Server Installation Script

USAGE:
    $0 [OPTIONS]

OPTIONS:
    --install         Install Meteor server (default)
    --uninstall       Uninstall Meteor server
    --help            Show this help message
    --version         Show version information
    --cores NUM       Number of CPU cores to use (default: $DEFAULT_CORES)
    --shards NUM      Number of shards (should match cores) (default: $DEFAULT_SHARDS)
    --memory MB       Maximum memory in MB (default: $DEFAULT_MEMORY)
    --port PORT       Server port (default: $DEFAULT_PORT)
    --enable-ssd-cache Enable SSD cache (EXPERIMENTAL - may cause hangs with pipeline=1)
    --recovery-mode MODE Recovery mode: auto, fresh, snapshot-only, aof-only, full, gcs-fallback (default: auto)

RECOVERY MODES:
    auto             Load latest snapshot + AOF (recommended for production)
    fresh            Start with empty database (ignores existing data)
    snapshot-only    Load only from snapshot (ignore AOF)
    aof-only         Load only from AOF (ignore snapshots)
    full             Load both snapshot + AOF (same as auto)
    gcs-fallback     Try local first, fallback to GCS if no local data

EXAMPLES:
    $0                                    # Install with default settings (recovery-mode=auto)
    $0 --cores 16 --shards 16             # Install with 16 cores/shards
    $0 --memory 32768 --port 6380         # Custom memory and port
    $0 --cores 4 --shards 4 --memory 8192 # Smaller configuration
    $0 --recovery-mode fresh              # Start fresh (no data recovery)
    $0 --uninstall                        # Remove installation
    
USAGE
}

show_version() {
    if [ -f "$SCRIPT_DIR/bin/VERSION" ]; then
        cat "$SCRIPT_DIR/bin/VERSION"
    else
        echo "Version information not available"
    fi
}

install_meteor() {
    print_banner
    
    log "Starting Meteor Server installation..."
    
    # Check root privileges
    if [[ $EUID -ne 0 ]]; then
        echo "ERROR: This script must be run as root (use sudo)"
        exit 1
    fi
    
    # Parse configuration parameters
    local cores="$DEFAULT_CORES"
    local shards="$DEFAULT_SHARDS"
    local memory="$DEFAULT_MEMORY"
    local port="$DEFAULT_PORT"
    local recovery_mode="auto"  # Default: always preserve data on restarts
    
    # Parse command line arguments
    local enable_ssd_cache="false"
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --cores)
                cores="$2"
                shift 2
                ;;
            --shards)
                shards="$2"
                shift 2
                ;;
            --memory)
                memory="$2"
                shift 2
                ;;
            --port)
                port="$2"
                shift 2
                ;;
            --enable-ssd-cache)
                enable_ssd_cache="true"
                shift
                ;;
            --recovery-mode)
                recovery_mode="$2"
                shift 2
                ;;
            *)
                shift
                ;;
        esac
    done
    
    # Allow higher core count for C++17 testing
    log "✅ Using C++17 build - testing with cores=$cores (no artificial limits)"
    
    log "Configuration: Cores=$cores, Shards=$shards, Memory=${memory}MB, Port=$port, SSD Cache=$enable_ssd_cache, Recovery Mode=$recovery_mode"
    
    # Detect Ubuntu version and setup jemalloc for Ubuntu 24
    detect_and_setup_jemalloc() {
        if [ -f /etc/os-release ]; then
            . /etc/os-release
            if [ "$ID" = "ubuntu" ] && [[ "$VERSION_ID" == "24."* ]]; then
                log "Detected Ubuntu 24.x - Installing jemalloc for optimal performance..."
                apt update && apt install -y libjemalloc2 libjemalloc-dev || {
                    warn "Failed to install jemalloc, continuing with system malloc"
                }
            else
                log "Detected $ID $VERSION_ID - Using system memory allocator"
            fi
        fi
    }
    
    # Setup jemalloc if Ubuntu 24
    detect_and_setup_jemalloc
    
    # Run deployment script with configuration
    if [ -f "$SCRIPT_DIR/scripts/deploy_meteor.sh" ]; then
        cd "$SCRIPT_DIR"
        SSD_CACHE_ENABLED="$enable_ssd_cache" METEOR_CORES="$cores" METEOR_SHARDS="$shards" METEOR_MEMORY="$memory" METEOR_PORT="$port" METEOR_RECOVERY_MODE="$recovery_mode" bash scripts/deploy_meteor.sh
    else
        echo "ERROR: Deployment script not found"
        exit 1
    fi
    
    log "Installation completed successfully!"
}

uninstall_meteor() {
    log "Starting Meteor Server uninstallation..."
    
    # Check root privileges
    if [[ $EUID -ne 0 ]]; then
        echo "ERROR: This script must be run as root (use sudo)"
        exit 1
    fi
    
    # Stop service
    systemctl stop meteor 2>/dev/null || true
    systemctl disable meteor 2>/dev/null || true
    
    # Remove service file
    rm -f /etc/systemd/system/meteor.service
    systemctl daemon-reload
    
    # Remove user and directories
    userdel meteor 2>/dev/null || true
    rm -rf /opt/meteor
    rm -rf /var/lib/meteor
    rm -rf /var/log/meteor
    rm -rf /etc/meteor
    
    # Remove system configurations
    rm -f /etc/sysctl.d/99-meteor.conf
    rm -f /etc/security/limits.d/99-meteor.conf
    rm -f /etc/logrotate.d/meteor
    rm -f /etc/cron.d/meteor-metrics
    
    log "Uninstallation completed"
}

# Main function
main() {
    # Check if first arg is an action or a parameter
    if [[ "$#" -eq 0 ]] || [[ "$1" == --* && "$1" != "--install" && "$1" != "--uninstall" && "$1" != "--help" && "$1" != "--version" ]]; then
        # No action specified or first arg is a config param, default to install
        install_meteor "$@"
    else
        local action="$1"
        shift
        
        case "$action" in
            --install|install)
                install_meteor "$@"
                ;;
            --uninstall|uninstall)
                uninstall_meteor
                ;;
            --version|version)
                show_version
                ;;
            --help|help|-h)
                show_usage
                ;;
            *)
                echo "Unknown option: $action"
                show_usage
                exit 1
                ;;
        esac
    fi
}

main "$@"
INSTALL_REST

    chmod +x "$PACKAGE_FULL_NAME/install.sh"
    
    log "Installation script created"
}

# Create documentation
create_documentation() {
    log "Creating documentation..."
    
    # Copy main README
    cp deployment/README.md "$PACKAGE_FULL_NAME/docs/README.md"
    
    # Create package-specific README
    cat > "$PACKAGE_FULL_NAME/README.md" << README
# Meteor Server v$PACKAGE_VERSION - Ubuntu $UBUNTU_VERSION Edition

High-performance Redis-compatible server with $OPTIMIZATION_TYPE optimization and advanced features including TTL, LRU eviction, and enterprise-grade monitoring.

## Version Information
- **Ubuntu Version**: $UBUNTU_VERSION
- **Optimization**: $OPTIMIZATION_TYPE  
- **jemalloc Support**: $JEMALLOC_SUPPORT
- **Package**: $PACKAGE_FULL_NAME

## Quick Installation

\`\`\`bash
# Extract package
tar -xzf ${PACKAGE_FULL_NAME}.tar.gz

# Install (requires root privileges)
cd ${PACKAGE_FULL_NAME}
sudo ./install.sh
\`\`\`

## Package Contents

- **bin/**: Server binary and utilities
- **etc/**: Configuration files
- **scripts/**: Deployment and maintenance scripts
- **systemd/**: System service definitions
- **monitoring/**: Telegraf and Grafana configurations
- **docs/**: Detailed documentation

## System Requirements

- **OS**: Linux (Ubuntu 18.04+, CentOS 7+, RHEL 7+)
- **CPU**: x86_64 with AVX2 support (AVX-512 recommended)
- **Memory**: 4GB RAM minimum (8GB+ recommended)
- **Storage**: 1GB free space for installation
- **Network**: TCP port 6379 available

## Features

### Core Features
- ✅ **Redis Protocol Compatible**: Drop-in replacement for Redis
- ✅ **High Performance**: Multi-threaded, NUMA-aware architecture
- ✅ **TTL Support**: Automatic key expiration with configurable policies
- ✅ **LRU Eviction**: Intelligent memory management
- ✅ **Pipeline Support**: Batch operation processing

### Enterprise Features
- ✅ **Production Ready**: Systemd integration with auto-restart
- ✅ **Monitoring**: Prometheus metrics and Grafana dashboards
- ✅ **Security**: Process isolation and resource limits
- ✅ **Backup**: Automated backup and recovery procedures
- ✅ **Logging**: Structured logging with rotation

### Performance Optimizations
- ✅ **SIMD Instructions**: AVX-512/AVX2 vectorization
- ✅ **io_uring**: Asynchronous I/O for Linux
- ✅ **Work Stealing**: Dynamic load balancing across cores
- ✅ **CPU Affinity**: Thread-to-core binding for optimal performance
- ✅ **Zero-Copy**: Memory-efficient data handling

## Configuration

Default configuration is optimized for production use. Key settings:

\`\`\`bash
# Performance
cores = 8
memory = 16384  # MB
work-stealing = true

# Network
bind = 0.0.0.0
port = 6379

# Features
ttl-enabled = true
metrics-enabled = true
\`\`\`

See \`etc/meteor.conf\` for complete configuration options.

## Service Management

\`\`\`bash
# Start/stop service
sudo systemctl start meteor
sudo systemctl stop meteor

# Check status
sudo systemctl status meteor

# View logs
sudo journalctl -u meteor -f

# Health check
redis-cli -h 127.0.0.1 -p 6379 ping
\`\`\`

## Monitoring

### Metrics Endpoint
- **URL**: http://localhost:8001/metrics
- **Format**: Prometheus format
- **Update**: Every 10 seconds

### Grafana Dashboard
Import the dashboard from \`monitoring/grafana_dashboard.json\`

### Key Metrics
- Operations per second
- Cache hit/miss rates
- Memory usage
- Connected clients
- Response time distribution

## Support

- **Documentation**: See \`docs/README.md\` for detailed information
- **Configuration**: Complete parameter reference in config files
- **Troubleshooting**: Common issues and solutions documented

## Version Information

- **Version**: $PACKAGE_VERSION
- **Build Date**: $BUILD_DATE
- **Binary**: $BINARY_NAME

---

For enterprise support and advanced features, contact the Meteor development team.
README

    # Create changelog
    cat > "$PACKAGE_FULL_NAME/CHANGELOG.md" << CHANGELOG
# Meteor Server Changelog

## v8.0.0 ($BUILD_DATE)

### New Features
- ✅ **TTL Support**: Complete time-to-live functionality with SETEX, TTL, EXPIRE commands
- ✅ **Enterprise Deployment**: Production-ready deployment scripts with systemd integration
- ✅ **Monitoring Integration**: Prometheus metrics endpoint and Grafana dashboards
- ✅ **Security Hardening**: Process isolation, resource limits, and secure defaults
- ✅ **Automated Backup**: Scheduled backup system with retention policies

### Performance Improvements
- ✅ **Race Condition Fixes**: Eliminated segfaults in pipeline=1 mode under high load
- ✅ **Work Stealing Optimization**: Dynamic load balancing for better CPU utilization
- ✅ **Memory Management**: LRU eviction with configurable policies
- ✅ **SIMD Optimizations**: AVX-512/AVX2 vectorization for data processing

### Enterprise Features
- ✅ **Production Configuration**: Optimized settings for enterprise deployment
- ✅ **Health Monitoring**: Comprehensive health checks and alerting
- ✅ **Log Management**: Structured logging with automatic rotation
- ✅ **Documentation**: Complete deployment and operations guide

### Bug Fixes
- 🔧 Fixed segmentation faults under high concurrent load
- 🔧 Resolved thread-local buffer corruption in batch processing
- 🔧 Improved error handling and graceful degradation
- 🔧 Enhanced connection management and client timeout handling

### Known Issues
- ⚠️  8-core configuration may experience instability under specific loads
- ⚠️  Performance differential between pipeline=1 and pipeline>1 modes

### Migration Notes
- Configuration file format updated with new TTL parameters
- Default memory eviction policy changed to volatile-lru
- Metrics endpoint moved to port 8001 (configurable)

---

For complete version history, see git commit log.
CHANGELOG

    log "Documentation created"
}

# Create dependency information
create_dependency_info() {
    log "Creating dependency information..."
    
    cat > "$PACKAGE_FULL_NAME/DEPENDENCIES.md" << DEPS
# Meteor Server Dependencies

## Runtime Dependencies

### Required Libraries
- **System Dependencies**: Boost libraries installed via apt package manager
- **No Bundled Libraries**: Relies on system-provided Boost for better compatibility
- **liburing**: io_uring library for asynchronous I/O (Linux)
- **libnuma**: NUMA library for memory management (optional)

### System Requirements
- **glibc**: GNU C Library 2.17+ (usually satisfied on modern Linux)
- **libstdc++**: Standard C++ Library (GCC 7.0+ or equivalent)
- **libpthread**: POSIX threads library
- **librt**: POSIX real-time extensions

### Optional Dependencies
- **libjemalloc**: Alternative memory allocator (recommended for production)
- **libtcmalloc**: Google's thread-caching malloc (alternative to jemalloc)

## Build Dependencies (for compilation)

### Compilers
- **GCC 7.0+** with C++17 support
- **Clang 6.0+** with C++17 support (alternative)

### Build Tools
- **CMake 3.10+** (if using CMake build system)
- **Make** (GNU Make 4.0+)
- **pkg-config** for library detection

### Development Libraries
- **libboost-dev** (1.65+): Boost development headers
- **liburing-dev**: io_uring development headers
- **libnuma-dev**: NUMA development headers

## Installation Commands

### Ubuntu/Debian
\`\`\`bash
sudo apt update
sudo apt install -y \\
    libboost-fiber-dev \\
    libboost-context-dev \\
    libboost-system-dev \\
    liburing-dev \\
    libnuma-dev
\`\`\`

### CentOS/RHEL/Fedora
\`\`\`bash
# Enable EPEL repository first
sudo yum install -y epel-release

sudo yum install -y \\
    boost-devel \\
    liburing-devel \\
    numactl-devel
\`\`\`

### Alpine Linux
\`\`\`bash
apk add --no-cache \\
    boost-dev \\
    liburing-dev \\
    numactl-dev
\`\`\`

## Version Compatibility

### Tested Versions
- **Boost**: 1.65.1, 1.71.0, 1.74.0
- **liburing**: 0.7, 2.0+
- **GCC**: 7.5, 9.4, 11.2
- **Linux Kernel**: 4.15+ (for io_uring support)

### Minimum Versions
- **Boost**: 1.65.0
- **liburing**: 0.7
- **Linux Kernel**: 4.15 (for full io_uring support)

## Static Linking

For deployment flexibility, consider static linking:
\`\`\`bash
g++ -static-libgcc -static-libstdc++ ...
\`\`\`

## Troubleshooting

### Common Issues
1. **liburing not found**: Install liburing-dev package
2. **Boost version too old**: Upgrade to Boost 1.65+
3. **AVX instructions not supported**: Use -mno-avx512f -mno-avx2 flags
4. **NUMA library missing**: Install libnuma-dev (optional)

### Dependency Check
Run the deployment script - it will automatically check and install dependencies.

---

The deployment script handles all dependency installation automatically.
DEPS

    log "Dependency information created"
}

# Create the final package
create_package() {
    log "Creating distributable package..."
    
    # Create tarball
    tar -czf "${PACKAGE_FULL_NAME}.tar.gz" "$PACKAGE_FULL_NAME/"
    
    # Get package size
    PACKAGE_SIZE=$(du -h "${PACKAGE_FULL_NAME}.tar.gz" | cut -f1)
    
    # Create checksum
    sha256sum "${PACKAGE_FULL_NAME}.tar.gz" > "${PACKAGE_FULL_NAME}.tar.gz.sha256"
    
    # Clean up temporary directory
    rm -rf "$PACKAGE_FULL_NAME"
    
    log "Package created successfully!"
    info "Package: ${PACKAGE_FULL_NAME}.tar.gz"
    info "Size: $PACKAGE_SIZE"
    info "Checksum: ${PACKAGE_FULL_NAME}.tar.gz.sha256"
}

# Create distribution information
create_distribution_info() {
    log "Creating distribution information..."
    
    cat > "${PACKAGE_FULL_NAME}-INFO.txt" << INFO
METEOR SERVER DISTRIBUTION PACKAGE
==================================

Package Name: ${PACKAGE_FULL_NAME}.tar.gz
Version: $PACKAGE_VERSION
Build Date: $BUILD_DATE
Binary: $BINARY_NAME

INSTALLATION:
1. Extract: tar -xzf ${PACKAGE_FULL_NAME}.tar.gz
2. Install: cd ${PACKAGE_FULL_NAME} && sudo ./install.sh

REQUIREMENTS:
- Linux OS (Ubuntu 18.04+, CentOS 7+, RHEL 7+)
- Root privileges for installation
- 4GB RAM minimum
- x86_64 CPU with AVX2 support

FEATURES:
- Redis-compatible protocol
- TTL and LRU support
- High-performance architecture
- Enterprise monitoring
- Production-ready deployment

SUPPORT:
- Documentation included in package
- Configuration examples provided
- Monitoring dashboards included

Build Information:
- Source: $BINARY_SOURCE
- Git Commit: $(git rev-parse --short HEAD 2>/dev/null || echo "unknown")
- Build Host: $(hostname)
- Packaged by: $(whoami)

Package Integrity:
- SHA256 checksum provided
- All files integrity verified

INFO

    log "Distribution information created"
}

# Print final summary
print_summary() {
    cat << SUMMARY

🎉 METEOR SERVER PACKAGE CREATED SUCCESSFULLY!

📦 DISTRIBUTION PACKAGE:
========================
Package: ${PACKAGE_FULL_NAME}.tar.gz
Size: $(du -h "${PACKAGE_FULL_NAME}.tar.gz" | cut -f1)
Checksum: ${PACKAGE_FULL_NAME}.tar.gz.sha256

🔧 VERSION INFORMATION:
======================
✅ Ubuntu Version: $UBUNTU_VERSION
✅ CPU Detected: $CPU_CAPABILITIES
✅ Optimization: $OPTIMIZATION_TYPE
✅ jemalloc Support: $JEMALLOC_SUPPORT
✅ Package Version: $PACKAGE_VERSION
✅ Binary Source: $BINARY_SOURCE

📋 PACKAGE CONTENTS:
====================
✅ Meteor server binary (meteor-server) - $OPTIMIZATION_TYPE optimized
✅ Enterprise deployment scripts
✅ Production configuration templates
✅ Systemd service definitions with jemalloc for Ubuntu 24
✅ Monitoring configurations (Telegraf/Grafana)
✅ Backup and recovery scripts
✅ Complete documentation
✅ Installation/uninstallation scripts

🚀 DISTRIBUTION READY:
======================
This package can be distributed independently without source code or compilation dependencies.
Perfect for enterprise deployment to any Ubuntu 24 VM.

INSTALLATION EXAMPLE:
# On target server
tar -xzf ${PACKAGE_FULL_NAME}.tar.gz
cd ${PACKAGE_FULL_NAME}
sudo ./install.sh

UNINSTALLATION:
sudo ./install.sh --uninstall

🔍 FILES CREATED:
==================
- ${PACKAGE_FULL_NAME}.tar.gz         (Main package)
- ${PACKAGE_FULL_NAME}.tar.gz.sha256  (Integrity checksum)
- ${PACKAGE_FULL_NAME}-INFO.txt       (Distribution information)

The package is now ready for enterprise distribution! 🎯

SUMMARY
}

# Main execution
main() {
    print_banner
    
    setup_binary_source
    validate_prerequisites
    create_package_structure
    prepare_binary
    copy_deployment_files
    create_install_script
    create_documentation
    create_dependency_info
    create_distribution_info
    create_package
    
    print_summary
}

# Handle command line arguments and run main
case "${1:-24}" in
    24|22)
        main
        ;;
    *)
        echo "Error: Invalid Ubuntu version '$1'. Use 22 or 24."
        echo "Run '$0 --help' for usage information."
        exit 1
        ;;
esac
